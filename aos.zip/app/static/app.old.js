const state = {
  dashboard: null,
  runs: [],
  memories: [],
  evals: null,
  selectedRunId: Number(document.body.dataset.initialRunId || 0) || null,
  selectedRun: null,
  traceFilter: 'all',
  runSearch: '',
};

const els = {
  providerBadge: document.getElementById('provider-badge'),
  modelBadge: document.getElementById('model-badge'),
  refresh: document.getElementById('refresh-dashboard'),
  goalForm: document.getElementById('goal-form'),
  goalInput: document.getElementById('goal-input'),
  runButton: document.getElementById('run-button'),
  runProgress: document.getElementById('run-progress'),
  metricTotalRuns: document.getElementById('metric-total-runs'),
  metricAvgScore: document.getElementById('metric-avg-score'),
  metricAvgDuration: document.getElementById('metric-avg-duration'),
  metricReflectionRate: document.getElementById('metric-reflection-rate'),
  scoreChart: document.getElementById('score-chart'),
  latencyChart: document.getElementById('latency-chart'),
  runsChart: document.getElementById('runs-chart'),
  providerChart: document.getElementById('provider-chart'),
  roleChart: document.getElementById('role-chart'),
  traceVolumePill: document.getElementById('trace-volume-pill'),
  runSearch: document.getElementById('run-search'),
  runsList: document.getElementById('runs-list'),
  detailTitle: document.getElementById('detail-title'),
  detailEmpty: document.getElementById('detail-empty'),
  detailContent: document.getElementById('detail-content'),
  detailActions: document.getElementById('detail-actions'),
  openRunLink: document.getElementById('open-run-link'),
  copyRunJson: document.getElementById('copy-run-json'),
  runStatus: document.getElementById('run-status'),
  runProvider: document.getElementById('run-provider'),
  runScore: document.getElementById('run-score'),
  runLatency: document.getElementById('run-latency'),
  runTraces: document.getElementById('run-traces'),
  runGoal: document.getElementById('run-goal'),
  runPlan: document.getElementById('run-plan'),
  runAnswer: document.getElementById('run-answer'),
  agentsGrid: document.getElementById('agents-grid'),
  traceFilters: document.getElementById('trace-filters'),
  traceTimeline: document.getElementById('trace-timeline'),
  memoryList: document.getElementById('memory-list'),
  memoryCountPill: document.getElementById('memory-count-pill'),
  evalSuiteCount: document.getElementById('eval-suite-count'),
  evalRunCount: document.getElementById('eval-run-count'),
  evalAvgScore: document.getElementById('eval-avg-score'),
  evalAvgPassRate: document.getElementById('eval-avg-pass-rate'),
  evalSuiteGrid: document.getElementById('eval-suite-grid'),
  evalScoreChart: document.getElementById('eval-score-chart'),
  evalPassChart: document.getElementById('eval-pass-chart'),
  evalSuiteMix: document.getElementById('eval-suite-mix'),
  evalRunsList: document.getElementById('eval-runs-list'),
  evalFailures: document.getElementById('eval-failures'),
  autoEvalToggle: document.getElementById('auto-eval-toggle'),
  defaultSuiteSelect: document.getElementById('default-suite-select'),
  runBenchmarkButton: document.getElementById('run-benchmark-button'),
  evalLastSuite: document.getElementById('eval-last-suite'),
};

function escapeHtml(str = '') {
  return String(str).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

function formatDuration(ms) {
  const value = Number(ms || 0);
  if (value < 1000) return `${Math.round(value)} ms`;
  const seconds = value / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)} s`;
  const minutes = seconds / 60;
  if (minutes < 60) return `${minutes.toFixed(1)} min`;
  const hours = minutes / 60;
  if (hours < 24) return `${hours.toFixed(1)} hr`;
  const days = hours / 24;
  if (days < 30) return `${days.toFixed(1)} d`;
  const months = days / 30;
  if (months < 12) return `${months.toFixed(1)} mo`;
  const years = months / 12;
  return `${years.toFixed(1)} yr`;
}

async function getJson(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error(`Request failed: ${response.status}`);
  return response.json();
}

function renderLineChart(container, series, label) {
  if (!container) return;
  if (!series?.length) {
    container.innerHTML = '<div class="empty-state">Not enough data yet.</div>';
    return;
  }
  const width = 640;
  const height = 220;
  const padding = 24;
  const max = Math.max(...series, 1);
  const min = Math.min(...series, 0);
  const range = Math.max(max - min, 1);
  const points = series.map((value, index) => {
    const x = padding + (index * ((width - padding * 2) / Math.max(series.length - 1, 1)));
    const y = height - padding - ((value - min) / range) * (height - padding * 2);
    return [x, y, value];
  });
  const polyline = points.map(([x, y]) => `${x},${y}`).join(' ');
  container.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${label}">
      <defs>
        <linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stop-color="rgba(122,163,255,0.55)"></stop>
          <stop offset="100%" stop-color="rgba(122,163,255,0.02)"></stop>
        </linearGradient>
      </defs>
      <polyline fill="none" stroke="rgba(145,174,255,0.95)" stroke-width="3" points="${polyline}"></polyline>
      ${points.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="4" fill="#dce7ff"></circle>`).join('')}
      <text x="${padding}" y="18">${label}</text>
      <text x="${padding}" y="${height - 8}">${min.toFixed(2)}</text>
      <text x="${width - padding}" y="${padding}" text-anchor="end">${max.toFixed(2)}</text>
    </svg>`;
}

function renderBarChart(container, items, labelKey, valueKey) {
  if (!container) return;
  if (!items?.length) {
    container.innerHTML = '<div class="empty-state">Not enough data yet.</div>';
    return;
  }
  const max = Math.max(...items.map((item) => item[valueKey]), 1);
  container.innerHTML = items.map((item) => `
    <div class="bar-row">
      <div class="bar-label">${escapeHtml(String(item[labelKey]))}</div>
      <div class="bar-track"><span style="width:${(item[valueKey] / max) * 100}%"></span></div>
      <div class="bar-value">${item[valueKey]}</div>
    </div>`).join('');
}

function renderMetrics(data) {
  const stats = data.stats;
  const config = data.config;
  els.metricTotalRuns.textContent = stats.total_runs;
  els.metricAvgScore.textContent = Number(stats.avg_score).toFixed(2);
  els.metricAvgDuration.textContent = formatDuration(stats.avg_duration_ms);
  els.metricReflectionRate.textContent = `${stats.reflection_rate}%`;
  els.traceVolumePill.textContent = `${stats.trace_volume} events`;
  els.providerBadge.textContent = `${config.provider.toUpperCase()} runtime`;
  els.modelBadge.textContent = config.model_name;
  els.memoryCountPill.textContent = `${state.memories.length} memories`;
}

function filteredRuns() {
  const query = state.runSearch.trim().toLowerCase();
  if (!query) return state.runs;
  return state.runs.filter((run) => run.goal.toLowerCase().includes(query));
}

function renderRuns() {
  const runs = filteredRuns();
  if (!runs.length) {
    els.runsList.className = 'runs-list empty-state';
    els.runsList.innerHTML = 'No runs match your filter yet.';
    return;
  }
  els.runsList.className = 'runs-list';
  els.runsList.innerHTML = runs.map((run) => `
    <article class="run-card ${state.selectedRunId === run.id ? 'active' : ''}" data-run-id="${run.id}">
      <div class="run-meta"><span class="status-pill">${escapeHtml(run.status)}</span><span>${formatDate(run.created_at)}</span></div>
      <h4>Run #${run.id}</h4>
      <p>${escapeHtml(run.goal_preview)}</p>
      <div class="run-meta footer"><span>${escapeHtml((run.provider || 'demo').toUpperCase())}</span><span>Score ${Number(run.critic_score).toFixed(2)}</span><span>${formatDuration(run.duration_ms)}</span></div>
    </article>`).join('');
  document.querySelectorAll('.run-card').forEach((card) => {
    card.addEventListener('click', () => selectRun(Number(card.dataset.runId)));
  });
}

function renderMemories() {
  if (!state.memories.length) {
    els.memoryList.innerHTML = '<div class="empty-state">No memories yet.</div>';
    return;
  }
  els.memoryList.innerHTML = state.memories.map((memory) => `
    <article class="memory-card">
      <div class="memory-top"><span class="memory-category">${escapeHtml(memory.category)}</span><span class="memory-importance">Importance ${Number(memory.importance || 0).toFixed(2)}</span></div>
      <p>${escapeHtml(memory.content)}</p>
      <span class="memory-time">${formatDate(memory.created_at)}</span>
    </article>`).join('');
}

function renderAgentPanels() {
  const panels = state.selectedRun?.agent_panels;
  if (!panels) {
    els.agentsGrid.innerHTML = '';
    return;
  }
  const order = ['planner', 'researcher', 'executor', 'critic', 'reflector', 'memory'];
  els.agentsGrid.innerHTML = order.map((role) => {
    const panel = panels[role];
    return `
      <article class="agent-card">
        <div class="agent-header">
          <div><div class="agent-role">${escapeHtml(panel.role)}</div><div class="agent-meta">${panel.count} event${panel.count === 1 ? '' : 's'}</div></div>
          <span class="pill">${escapeHtml(panel.latest_event)}</span>
        </div>
        <pre>${escapeHtml(panel.latest_content)}</pre>
      </article>`;
  }).join('');
}

function renderTraceFilters() {
  const roles = ['all', 'planner', 'researcher', 'executor', 'critic', 'reflector', 'memory'];
  els.traceFilters.innerHTML = roles.map((role) => `<button class="filter-chip ${state.traceFilter === role ? 'active' : ''}" data-role="${role}">${role}</button>`).join('');
  els.traceFilters.querySelectorAll('.filter-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      state.traceFilter = chip.dataset.role;
      renderTraceFilters();
      renderTraceTimeline();
    });
  });
}

function renderTraceTimeline() {
  const traces = state.selectedRun?.traces || [];
  const visible = state.traceFilter === 'all' ? traces : traces.filter((trace) => trace.role === state.traceFilter);
  if (!visible.length) {
    els.traceTimeline.innerHTML = '<div class="empty-state">No traces for this filter.</div>';
    return;
  }
  els.traceTimeline.innerHTML = visible.map((trace) => `
    <article class="trace-item role-${trace.role}">
      <div class="trace-top"><span class="trace-role">${escapeHtml(trace.role)}</span><span class="trace-event">${escapeHtml(trace.event_type)}</span><span class="trace-time">${formatDate(trace.created_at)}</span></div>
      <pre>${escapeHtml(trace.content)}</pre>
    </article>`).join('');
}

function renderSelectedRun() {
  if (!state.selectedRun) {
    els.detailTitle.textContent = 'Choose a run';
    els.detailEmpty.classList.remove('hidden');
    els.detailContent.classList.add('hidden');
    els.detailActions.classList.add('hidden');
    return;
  }
  const run = state.selectedRun;
  els.detailTitle.textContent = `Run #${run.id}`;
  els.detailEmpty.classList.add('hidden');
  els.detailContent.classList.remove('hidden');
  els.detailActions.classList.remove('hidden');
  els.openRunLink.href = `/runs/${run.id}`;
  els.runStatus.textContent = run.status;
  els.runProvider.textContent = `${(run.provider || 'demo').toUpperCase()} / ${run.model_name || '-'}`;
  els.runScore.textContent = Number(run.critic_score).toFixed(2);
  els.runLatency.textContent = formatDuration(run.duration_ms);
  els.runTraces.textContent = run.trace_count;
  els.runGoal.textContent = run.goal;
  els.runPlan.textContent = run.plan_text;
  els.runAnswer.textContent = run.final_answer;
  renderAgentPanels();
  renderTraceFilters();
  renderTraceTimeline();
}

async function selectRun(runId) {
  state.selectedRunId = runId;
  renderRuns();
  state.selectedRun = await getJson(`/api/runs/${runId}`);
  renderSelectedRun();
  history.replaceState({}, '', `/runs/${runId}`);
}


function getAutoEvalEnabled() {
  return localStorage.getItem('aos:autoEvalEnabled') === 'true';
}

function getDefaultSuiteName() {
  return localStorage.getItem('aos:defaultEvalSuite') || '';
}

function setDefaultSuiteName(value) {
  localStorage.setItem('aos:defaultEvalSuite', value || '');
}

function setAutoEvalEnabled(value) {
  localStorage.setItem('aos:autoEvalEnabled', value ? 'true' : 'false');
}

async function triggerBenchmarkRun(suiteName, button = null) {
  if (!suiteName) return;
  const original = button ? button.textContent : null;
  if (button) {
    button.disabled = true;
    button.textContent = 'Running...';
  }
  try {
    await getJson('/api/evals/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ suite_name: suiteName }),
    });
    await loadDashboard();
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = original;
    }
  }
}

function syncBenchmarkControls(evals) {
  if (!els.defaultSuiteSelect) return;
  const suites = evals?.suites || [];
  const stored = getDefaultSuiteName();
  const fallback = suites[0]?.name || '';
  const selected = suites.some((suite) => suite.name === stored) ? stored : fallback;
  els.defaultSuiteSelect.innerHTML = suites.map((suite) => `<option value="${escapeHtml(suite.name)}">${escapeHtml(suite.title)} (${escapeHtml(suite.name)})</option>`).join('');
  if (selected) {
    els.defaultSuiteSelect.value = selected;
    setDefaultSuiteName(selected);
  }
  els.evalLastSuite.textContent = `Default suite: ${selected || '-'}`;
  els.autoEvalToggle.checked = getAutoEvalEnabled();
  els.runBenchmarkButton.disabled = !selected;
}

function renderEvalSuites(evals) {
  if (!els.evalSuiteGrid) return;
  els.evalSuiteCount.textContent = `${evals.stats.suite_count} suites`;
  els.evalRunCount.textContent = `${evals.stats.eval_run_count} eval runs`;
  els.evalAvgScore.textContent = Number(evals.stats.avg_eval_score).toFixed(3);
  els.evalAvgPassRate.textContent = `${Number(evals.stats.avg_pass_rate).toFixed(1)}%`;

  if (!evals.suites?.length) {
    els.evalSuiteGrid.innerHTML = '<div class="empty-state">No benchmark suites available.</div>';
    return;
  }
  els.evalSuiteGrid.innerHTML = evals.suites.map((suite) => `
    <article class="suite-card glass subtle-card">
      <div class="suite-head">
        <div>
          <p class="section-kicker">${escapeHtml(suite.name)}</p>
          <h4>${escapeHtml(suite.title)}</h4>
        </div>
        <button class="primary-button small-button run-suite-button" data-suite-name="${escapeHtml(suite.name)}">Run suite</button>
      </div>
      <p class="suite-copy">${escapeHtml(suite.description)}</p>
      <div class="suite-meta"><span>${suite.case_count} cases</span><span>${suite.cases.map((item) => item.eval_type).filter((v, i, arr) => arr.indexOf(v) === i).join(', ')}</span></div>
      <div class="suite-tags">${suite.cases.slice(0, 6).flatMap((item) => item.tags || []).slice(0, 8).map((tag) => `<span class="mini-badge">${escapeHtml(tag)}</span>`).join('')}</div>
    </article>`).join('');

  document.querySelectorAll('.run-suite-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const suiteName = button.dataset.suiteName;
      setDefaultSuiteName(suiteName);
      syncBenchmarkControls(evals);
      await triggerBenchmarkRun(suiteName, button);
    });
  });
}

function renderEvalRuns(evals) {
  if (!els.evalRunsList) return;
  if (!evals.recent_eval_runs?.length) {
    els.evalRunsList.className = 'runs-list empty-state';
    els.evalRunsList.innerHTML = 'No eval runs yet.';
    return;
  }
  els.evalRunsList.className = 'runs-list';
  els.evalRunsList.innerHTML = evals.recent_eval_runs.map((run) => `
    <article class="eval-run-card">
      <div class="run-meta"><span class="status-pill">${escapeHtml(run.status)}</span><span>${formatDate(run.created_at)}</span></div>
      <h4>${escapeHtml(run.suite_name)}</h4>
      <p>${escapeHtml((run.provider || 'demo').toUpperCase())} / ${escapeHtml(run.model_name || '-')}</p>
      <div class="run-meta footer"><span>Score ${Number(run.aggregate_score).toFixed(3)}</span><span>Pass ${Number(run.pass_rate).toFixed(1)}%</span><span>${run.total_cases} cases</span></div>
      <div class="eval-case-list">${run.results.map((result) => `<div class="eval-case-row ${result.passed ? 'pass' : 'fail'}"><span>${escapeHtml(result.case_name)}</span><span>${Number(result.score).toFixed(3)}</span></div>`).join('')}</div>
    </article>`).join('');
}

function renderLastBenchmarkBanner(evals) {
  if (!els.lastBenchmarkBanner) return;
  const latest = evals?.recent_eval_runs?.[0];
  if (!latest) {
    els.lastBenchmarkBanner.classList.remove('hidden');
    els.lastBenchmarkTitle.textContent = 'No benchmark run yet';
    els.lastBenchmarkStatus.textContent = 'Ready';
    els.lastBenchmarkStatus.className = 'pill success';
    els.lastBenchmarkCopy.textContent = 'Run a benchmark manually or enable auto-run after each agent run to see pass rate and score here.';
    els.lastBenchmarkSuite.textContent = '-';
    els.lastBenchmarkScore.textContent = '-';
    els.lastBenchmarkPassRate.textContent = '-';
    els.lastBenchmarkCases.textContent = '-';
    els.lastBenchmarkProvider.textContent = '-';
    els.lastBenchmarkTime.textContent = '-';
    return;
  }

  const passRate = Number(latest.pass_rate || 0);
  const score = Number(latest.aggregate_score || 0);
  const statusClass = passRate >= 85 ? 'pill success' : passRate >= 60 ? 'pill warning' : 'pill danger-soft';
  const statusLabel = passRate >= 85 ? 'Strong' : passRate >= 60 ? 'Mixed' : 'Needs work';
  const provider = (latest.provider || 'demo').toUpperCase();

  els.lastBenchmarkBanner.classList.remove('hidden');
  els.lastBenchmarkTitle.textContent = `${latest.suite_name} benchmark completed`;
  els.lastBenchmarkStatus.textContent = statusLabel;
  els.lastBenchmarkStatus.className = statusClass;
  els.lastBenchmarkCopy.textContent = `Latest suite scored ${score.toFixed(3)} with a ${passRate.toFixed(1)}% pass rate across ${latest.total_cases} cases on ${provider}.`;
  els.lastBenchmarkSuite.textContent = latest.suite_name;
  els.lastBenchmarkScore.textContent = score.toFixed(3);
  els.lastBenchmarkPassRate.textContent = `${passRate.toFixed(1)}%`;
  els.lastBenchmarkCases.textContent = String(latest.total_cases || 0);
  els.lastBenchmarkProvider.textContent = `${provider} / ${latest.model_name || '-'}`;
  els.lastBenchmarkTime.textContent = formatDate(latest.created_at);
}

function renderEvalFailures(evals) {
  if (!els.evalFailures) return;
  if (!evals.latest_failures?.length) {
    els.evalFailures.className = 'failure-list empty-state';
    els.evalFailures.innerHTML = 'No failures yet.';
    return;
  }
  els.evalFailures.className = 'failure-list';
  els.evalFailures.innerHTML = evals.latest_failures.map((failure) => `
    <article class="failure-card">
      <div class="failure-top"><span class="status-pill danger">Miss</span><span>${escapeHtml(failure.suite_name)}</span></div>
      <h4>${escapeHtml(failure.case_name)}</h4>
      <p>${escapeHtml(failure.judge_summary)}</p>
      <div class="run-meta footer"><span>Score ${Number(failure.score).toFixed(3)}</span>${failure.agent_run_id ? `<a href="/runs/${failure.agent_run_id}">Run #${failure.agent_run_id}</a>` : ''}</div>
    </article>`).join('');
}

function renderEvalDashboard(evals) {
  state.evals = evals;
  syncBenchmarkControls(evals);
  renderEvalSuites(evals);
  renderEvalRuns(evals);
  renderEvalFailures(evals);
  renderLastBenchmarkBanner(evals);
  renderLineChart(els.evalScoreChart, evals.charts.score_series, 'Aggregate eval score');
  renderLineChart(els.evalPassChart, evals.charts.pass_series, 'Pass rate');
  renderBarChart(els.evalSuiteMix, evals.charts.suite_mix, 'suite_name', 'count');
}

async function loadDashboard() {
  const data = await getJson('/api/dashboard');
  state.dashboard = data;
  state.runs = data.recent_runs;
  state.memories = data.memories;
  renderMetrics(data);
  renderLineChart(els.scoreChart, data.charts.score_series, 'Critic score');
  renderLineChart(els.latencyChart, data.charts.latency_series, 'Latency ms');
  renderBarChart(els.runsChart, data.charts.daily_counts, 'label', 'count');
  renderBarChart(els.providerChart, data.charts.provider_mix, 'provider', 'count');
  renderBarChart(els.roleChart, data.charts.role_distribution, 'role', 'count');
  renderRuns();
  renderMemories();
  renderEvalDashboard(data.evals);
  if (state.selectedRunId) {
    await selectRun(state.selectedRunId);
  } else if (state.runs.length) {
    await selectRun(state.runs[0].id);
  }
}

async function runGoal(goal) {
  els.runProgress.classList.remove('hidden');
  els.runButton.disabled = true;
  els.runBenchmarkButton.disabled = true;
  try {
    const autoEval = getAutoEvalEnabled();
    const evalSuiteName = getDefaultSuiteName();
    const result = await getJson('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goal, auto_eval: autoEval, eval_suite_name: evalSuiteName || null }),
    });
    state.selectedRunId = result.run_id;
    await loadDashboard();
  } finally {
    els.runProgress.classList.add('hidden');
    els.runButton.disabled = false;
    els.runBenchmarkButton.disabled = !getDefaultSuiteName();
  }
}

function setupEvents() {
  els.goalForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const goal = els.goalInput.value.trim();
    if (!goal) return;
    await runGoal(goal);
  });
  els.refresh.addEventListener('click', loadDashboard);
  els.autoEvalToggle?.addEventListener('change', (event) => {
    setAutoEvalEnabled(Boolean(event.target.checked));
  });
  els.defaultSuiteSelect?.addEventListener('change', (event) => {
    setDefaultSuiteName(event.target.value);
    if (state.evals) syncBenchmarkControls(state.evals);
  });
  els.runBenchmarkButton?.addEventListener('click', async () => {
    const suiteName = getDefaultSuiteName();
    await triggerBenchmarkRun(suiteName, els.runBenchmarkButton);
  });
  els.runSearch.addEventListener('input', (event) => {
    state.runSearch = event.target.value;
    renderRuns();
  });
  document.querySelectorAll('.prompt-chip').forEach((chip) => chip.addEventListener('click', () => {
    els.goalInput.value = chip.textContent.trim();
    els.goalInput.focus();
  }));
  document.querySelectorAll('.nav-pill').forEach((pill) => pill.addEventListener('click', () => {
    document.getElementById(pill.dataset.scrollTarget)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.querySelectorAll('.nav-pill').forEach((button) => button.classList.remove('active'));
    pill.classList.add('active');
  }));
  document.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((item) => item.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((item) => item.classList.remove('active'));
    tab.classList.add('active');
    document.querySelector(`.tab-panel[data-panel="${tab.dataset.tab}"]`)?.classList.add('active');
  }));
  els.copyRunJson.addEventListener('click', async () => {
    if (!state.selectedRun) return;
    await navigator.clipboard.writeText(JSON.stringify(state.selectedRun, null, 2));
    els.copyRunJson.textContent = 'Copied';
    setTimeout(() => { els.copyRunJson.textContent = 'Copy JSON'; }, 1200);
  });
}

setupEvents();
loadDashboard().catch((error) => {
  console.error(error);
  document.body.insertAdjacentHTML('beforeend', `<div class="toast">Could not load dashboard: ${escapeHtml(error.message)}</div>`);
});

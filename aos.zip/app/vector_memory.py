from __future__ import annotations

import hashlib
import math
import os
import re
from typing import Any, Iterable, List

import chromadb

from app.config import settings


class SimpleHashEmbeddingFunction:
    def __init__(self, dim: int = 256):
        self.dim = dim

    def _embed_one(self, text: str) -> list[float]:
        vec = [0.0] * self.dim
        tokens = re.findall(r"[a-zA-Z0-9_]+", text.lower())
        if not tokens:
            return vec
        for token in tokens:
            idx = int(hashlib.sha256(token.encode()).hexdigest(), 16) % self.dim
            vec[idx] += 1.0
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def __call__(self, input: Iterable[str]) -> List[List[float]]:
        return [self._embed_one(text) for text in input]


class VectorMemoryStore:
    def __init__(self) -> None:
        os.makedirs(settings.chroma_dir, exist_ok=True)
        self.client = chromadb.PersistentClient(path=settings.chroma_dir)
        self.collection = self.client.get_or_create_collection(
            name='agentos_memory',
            embedding_function=SimpleHashEmbeddingFunction(),
            metadata={'hnsw:space': 'cosine'},
        )

    def add_memory(self, vector_id: str, content: str, metadata: dict[str, Any]) -> None:
        self.collection.upsert(ids=[vector_id], documents=[content], metadatas=[metadata])

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        result = self.collection.query(query_texts=[query], n_results=limit)
        ids = result.get('ids', [[]])[0]
        docs = result.get('documents', [[]])[0]
        metas = result.get('metadatas', [[]])[0]
        distances = result.get('distances', [[]])[0]
        matches: list[dict[str, Any]] = []
        for vid, doc, meta, distance in zip(ids, docs, metas, distances):
            matches.append({'vector_id': vid, 'content': doc, 'metadata': meta or {}, 'distance': float(distance) if distance is not None else 0.0})
        return matches

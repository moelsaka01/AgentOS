from __future__ import annotations

from datetime import datetime
from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class MemoryItem(Base):
    __tablename__ = 'memory_items'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str] = mapped_column(String(50), default='general')
    importance: Mapped[float] = mapped_column(Float, default=0.5)
    vector_id: Mapped[str] = mapped_column(String(120), default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AgentRun(Base):
    __tablename__ = 'agent_runs'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    goal: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default='pending')
    provider: Mapped[str] = mapped_column(String(30), default='demo')
    model_name: Mapped[str] = mapped_column(String(120), default='demo-heuristic')
    depth_mode: Mapped[str] = mapped_column(String(20), default='deep')
    plan_text: Mapped[str] = mapped_column(Text, default='')
    final_answer: Mapped[str] = mapped_column(Text, default='')
    critic_score: Mapped[float] = mapped_column(Float, default=0.0)
    critic_feedback: Mapped[str] = mapped_column(Text, default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    traces: Mapped[list['TraceEvent']] = relationship('TraceEvent', back_populates='run', cascade='all, delete-orphan')


class TraceEvent(Base):
    __tablename__ = 'trace_events'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int] = mapped_column(ForeignKey('agent_runs.id'), index=True)
    role: Mapped[str] = mapped_column(String(50), nullable=False)
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    run: Mapped[AgentRun] = relationship('AgentRun', back_populates='traces')


class EvalSuite(Base):
    __tablename__ = 'eval_suites'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(160), default='')
    description: Mapped[str] = mapped_column(Text, default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    cases: Mapped[list['EvalCase']] = relationship('EvalCase', back_populates='suite', cascade='all, delete-orphan')


class EvalCase(Base):
    __tablename__ = 'eval_cases'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    suite_id: Mapped[int] = mapped_column(ForeignKey('eval_suites.id'), index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    goal: Mapped[str] = mapped_column(Text, nullable=False)
    eval_type: Mapped[str] = mapped_column(String(50), default='rubric')
    difficulty: Mapped[str] = mapped_column(String(30), default='medium')
    weight: Mapped[float] = mapped_column(Float, default=1.0)
    expected_answer: Mapped[str] = mapped_column(Text, default='')
    rubric_json: Mapped[str] = mapped_column(Text, default='{}')
    tags: Mapped[str] = mapped_column(String(240), default='')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    suite: Mapped['EvalSuite'] = relationship('EvalSuite', back_populates='cases')
    results: Mapped[list['EvalResult']] = relationship('EvalResult', back_populates='eval_case', cascade='all, delete-orphan')


class EvalRun(Base):
    __tablename__ = 'eval_runs'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    suite_name: Mapped[str] = mapped_column(String(100), index=True)
    status: Mapped[str] = mapped_column(String(30), default='running')
    provider: Mapped[str] = mapped_column(String(30), default='demo')
    model_name: Mapped[str] = mapped_column(String(120), default='demo-heuristic')
    depth_mode: Mapped[str] = mapped_column(String(20), default='deep')
    aggregate_score: Mapped[float] = mapped_column(Float, default=0.0)
    pass_rate: Mapped[float] = mapped_column(Float, default=0.0)
    total_cases: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    results: Mapped[list['EvalResult']] = relationship('EvalResult', back_populates='eval_run', cascade='all, delete-orphan')


class EvalResult(Base):
    __tablename__ = 'eval_results'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    eval_run_id: Mapped[int] = mapped_column(ForeignKey('eval_runs.id'), index=True)
    eval_case_id: Mapped[int] = mapped_column(ForeignKey('eval_cases.id'), index=True)
    agent_run_id: Mapped[int | None] = mapped_column(ForeignKey('agent_runs.id'), nullable=True)
    score: Mapped[float] = mapped_column(Float, default=0.0)
    passed: Mapped[int] = mapped_column(Integer, default=0)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    judge_summary: Mapped[str] = mapped_column(Text, default='')
    dimension_scores_json: Mapped[str] = mapped_column(Text, default='{}')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    eval_run: Mapped['EvalRun'] = relationship('EvalRun', back_populates='results')
    eval_case: Mapped['EvalCase'] = relationship('EvalCase', back_populates='results')

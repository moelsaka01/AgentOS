from __future__ import annotations

import json
from collections import Counter, defaultdict
from statistics import mean

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.agent_runtime import AgentRuntime
from app.config import settings
from app.db import Base, engine, get_db
from app.evals import BenchmarkRunner, EvalSeeder, serialize_eval_run
from app.llm import LLMProviderConfig
from openai import RateLimitError
from app.models import AgentRun, EvalCase, EvalResult, EvalRun, EvalSuite, MemoryItem
from app.schemas import EvalRunRequest, GoalRequest, GoalResponse
from app.seed import seed_memories
from app.tools import ToolRegistry

app = FastAPI(title=settings.app_name)

app.mount('/static', StaticFiles(directory='app/static'), name='static')
templates = Jinja2Templates(directory='app/templates')

ROLE_ORDER = ['planner', 'researcher', 'executor', 'critic', 'reflector', 'memory']
ROLE_EMPTY_STATE = {
    'planner': 'Planner has not produced a plan yet.',
    'researcher': 'Researcher has not synthesized context yet.',
    'executor': 'Executor has not produced a draft answer yet.',
    'critic': 'Critic has not produced feedback yet.',
    'reflector': 'Reflector was not needed for this run.',
    'memory': 'Memory service did not log a retrieval or write for this run.',
}


def _llm_override_from_payload(payload_override) -> LLMProviderConfig | None:
    if not payload_override:
        return None
    provider = (payload_override.provider or '').strip().lower()
    if not provider:
        return None
    return LLMProviderConfig(
        provider=provider,
        model_name=(payload_override.model_name or '').strip(),
        api_key=(payload_override.api_key or '').strip(),
        base_url=(payload_override.base_url or '').strip() or None,
    )


def ensure_schema() -> None:
    Base.metadata.create_all(bind=engine)
    inspector = inspect(engine)
    run_columns = {col['name'] for col in inspector.get_columns('agent_runs')} if inspector.has_table('agent_runs') else set()
    memory_columns = {col['name'] for col in inspector.get_columns('memory_items')} if inspector.has_table('memory_items') else set()
    with engine.begin() as conn:
        if 'provider' not in run_columns:
            conn.execute(text("ALTER TABLE agent_runs ADD COLUMN provider VARCHAR(30) DEFAULT 'demo'"))
        if 'model_name' not in run_columns:
            conn.execute(text("ALTER TABLE agent_runs ADD COLUMN model_name VARCHAR(120) DEFAULT 'demo-heuristic'"))
        if 'depth_mode' not in run_columns:
            conn.execute(text("ALTER TABLE agent_runs ADD COLUMN depth_mode VARCHAR(20) DEFAULT 'deep'"))
        if 'vector_id' not in memory_columns:
            conn.execute(text("ALTER TABLE memory_items ADD COLUMN vector_id VARCHAR(120) DEFAULT ''"))


ensure_schema()


@app.on_event('startup')
def on_startup() -> None:
    db = next(get_db())
    try:
        seed_memories(db)
        EvalSeeder(db).seed()
        ToolRegistry(db).sync_existing_memories()
    finally:
        db.close()


def _duration_ms(run: AgentRun) -> int:
    if not run.created_at or not run.updated_at:
        return 0
    return max(0, int((run.updated_at - run.created_at).total_seconds() * 1000))


def _serialize_trace(trace) -> dict:
    return {
        'id': trace.id,
        'role': trace.role,
        'event_type': trace.event_type,
        'content': trace.content,
        'created_at': trace.created_at,
    }


def _serialize_run_summary(run: AgentRun) -> dict:
    traces = getattr(run, 'traces', None) or []
    return {
        'id': run.id,
        'goal': run.goal,
        'status': run.status,
        'provider': run.provider,
        'model_name': run.model_name,
        'critic_score': round(float(run.critic_score or 0.0), 2),
        'depth_mode': getattr(run, 'depth_mode', 'deep') or 'deep',
        'critic_feedback': run.critic_feedback,
        'created_at': run.created_at,
        'updated_at': run.updated_at,
        'duration_ms': _duration_ms(run),
        'trace_count': len(traces),
        'goal_preview': (run.goal[:120] + '...') if len(run.goal) > 120 else run.goal,
    }


def _serialize_run_detail(run: AgentRun) -> dict:
    traces = sorted(run.traces, key=lambda item: item.created_at)
    agent_panels = {}
    for role in ROLE_ORDER:
        role_traces = [trace for trace in traces if trace.role == role]
        latest_content = role_traces[-1].content if role_traces else ROLE_EMPTY_STATE[role]
        latest_event = role_traces[-1].event_type if role_traces else 'idle'
        agent_panels[role] = {
            'role': role,
            'count': len(role_traces),
            'latest_event': latest_event,
            'latest_content': latest_content,
            'events': [_serialize_trace(trace) for trace in role_traces],
        }
    return {
        **_serialize_run_summary(run),
        'plan_text': run.plan_text,
        'final_answer': run.final_answer,
        'agent_panels': agent_panels,
        'traces': [_serialize_trace(trace) for trace in traces],
    }


def _eval_dashboard(db: Session) -> dict:
    suites = db.query(EvalSuite).order_by(EvalSuite.name.asc()).all()
    eval_runs = db.query(EvalRun).order_by(EvalRun.created_at.desc()).limit(20).all()
    results = db.query(EvalResult).order_by(EvalResult.created_at.desc()).limit(500).all()
    score_series = [round(float(run.aggregate_score), 3) for run in reversed(eval_runs)]
    pass_series = [round(float(run.pass_rate), 1) for run in reversed(eval_runs)]
    suite_mix = Counter(run.suite_name for run in eval_runs)
    latest_failures = [
        {
            'case_name': result.eval_case.name if result.eval_case else 'unknown',
            'suite_name': result.eval_run.suite_name if result.eval_run else 'unknown',
            'score': round(float(result.score), 3),
            'judge_summary': result.judge_summary,
            'agent_run_id': result.agent_run_id,
        }
        for result in results if not result.passed
    ][:8]
    return {
        'stats': {
            'suite_count': len(suites),
            'eval_run_count': len(eval_runs),
            'avg_eval_score': round(mean(score_series), 3) if score_series else 0.0,
            'avg_pass_rate': round(mean(pass_series), 1) if pass_series else 0.0,
        },
        'suites': [
            {
                'name': suite.name,
                'title': suite.title,
                'description': suite.description,
                'case_count': len(suite.cases),
                'cases': [
                    {
                        'id': case.id,
                        'name': case.name,
                        'difficulty': case.difficulty,
                        'eval_type': case.eval_type,
                        'weight': case.weight,
                        'tags': case.tags.split(',') if case.tags else [],
                    }
                    for case in suite.cases
                ],
            }
            for suite in suites
        ],
        'recent_eval_runs': [serialize_eval_run(run) for run in eval_runs],
        'charts': {
            'score_series': score_series,
            'pass_series': pass_series,
            'suite_mix': [{'suite_name': k, 'count': v} for k, v in suite_mix.items()],
        },
        'latest_failures': latest_failures,
    }


@app.get('/', response_class=HTMLResponse)
def home(request: Request, selected_run_id: int | None = None):
    return templates.TemplateResponse('dashboard.html', {'request': request, 'app_name': settings.app_name, 'selected_run_id': selected_run_id})


@app.get('/runs/{run_id}', response_class=HTMLResponse)
def run_detail_page(run_id: int, request: Request, db: Session = Depends(get_db)):
    exists = db.query(AgentRun.id).filter(AgentRun.id == run_id).first()
    if not exists:
        raise HTTPException(status_code=404, detail='Run not found')
    return templates.TemplateResponse('dashboard.html', {'request': request, 'app_name': settings.app_name, 'selected_run_id': run_id})


@app.post('/run', response_class=HTMLResponse)
def run_from_form(goal: str = Form(...), db: Session = Depends(get_db)):
    run = AgentRuntime(db).run_goal(goal)
    return RedirectResponse(url=f'/runs/{run.id}', status_code=303)


@app.post('/api/run', response_model=GoalResponse)
def run_goal(payload: GoalRequest, db: Session = Depends(get_db)):
    llm_override = _llm_override_from_payload(payload.llm_override)
    try:
        run = AgentRuntime(db, llm_override).run_goal(payload.goal, payload.depth_mode)
    except RateLimitError as exc:
        raise HTTPException(status_code=429, detail='Rate limit reached for the selected provider or model. Try a lighter model, wait for reset, or switch providers.') from exc
    eval_runs = []
    if payload.auto_eval and payload.eval_suite_name:
        try:
            eval_run = BenchmarkRunner(db, llm_override).run_suite(payload.eval_suite_name)
            eval_runs.append(serialize_eval_run(eval_run))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except RateLimitError as exc:
            raise HTTPException(status_code=429, detail='Rate limit reached while running benchmarks for the selected provider or model.') from exc
    return GoalResponse(
        run_id=run.id,
        status=run.status,
        final_answer=run.final_answer,
        critic_score=run.critic_score,
        critic_feedback=run.critic_feedback,
        eval_runs=eval_runs,
    )


@app.post('/api/evals/run')
def run_eval_suite(payload: EvalRunRequest, db: Session = Depends(get_db)):
    llm_override = _llm_override_from_payload(payload.llm_override)
    try:
        eval_run = BenchmarkRunner(db, llm_override).run_suite(payload.suite_name)
    except RateLimitError as exc:
        raise HTTPException(status_code=429, detail='Rate limit reached while running the selected benchmark suite.') from exc
    return {'eval_run': serialize_eval_run(eval_run)}


@app.get('/api/evals/dashboard')
def eval_dashboard(db: Session = Depends(get_db)):
    return _eval_dashboard(db)


@app.get('/api/evals/runs/{eval_run_id}')
def get_eval_run(eval_run_id: int, db: Session = Depends(get_db)):
    run = db.query(EvalRun).filter(EvalRun.id == eval_run_id).first()
    if not run:
        raise HTTPException(status_code=404, detail='Eval run not found')
    return serialize_eval_run(run)


@app.get('/api/config')
def config_status():
    active = settings.active_provider
    model = settings.groq_model if active == 'groq' else settings.openai_model if active == 'openai' else 'demo-heuristic'
    return {
        'app_name': settings.app_name,
        'provider': active,
        'model_name': model,
        'vector_memory': 'ChromaDB + hashed semantic embeddings',
        'multi_agent_roles': ROLE_ORDER,
        'recruiter_mode': True,
        'benchmarking': True,
        'runtime_depth_default': settings.runtime_depth_default,
        'runtime_depth_options': ['normal', 'deep', 'exhaustive'],
        'provider_options': [
            {'value': 'local', 'label': 'Local demo'},
            {'value': 'openai', 'label': 'OpenAI'},
            {'value': 'groq', 'label': 'Groq'},
            {'value': 'gemini', 'label': 'Gemini'},
            {'value': 'deepseek', 'label': 'DeepSeek'},
            {'value': 'openrouter', 'label': 'OpenRouter'},
            {'value': 'custom_openai', 'label': 'Custom OpenAI-compatible'},
        ],
    }


@app.get('/api/dashboard')
def dashboard_data(db: Session = Depends(get_db)):
    runs = db.query(AgentRun).order_by(AgentRun.created_at.desc()).limit(100).all()
    memories = db.query(MemoryItem).order_by(MemoryItem.created_at.desc()).limit(30).all()
    run_summaries = [_serialize_run_summary(run) for run in runs]
    score_series = [summary['critic_score'] for summary in reversed(run_summaries)]
    latency_series = [summary['duration_ms'] for summary in reversed(run_summaries)]

    per_day = defaultdict(int)
    provider_mix = Counter()
    role_distribution = Counter()
    total_traces = 0
    for run in runs:
        per_day[run.created_at.strftime('%b %d')] += 1
        provider_mix[run.provider] += 1
        for trace in run.traces:
            role_distribution[trace.role] += 1
            total_traces += 1

    memory_categories = Counter(memory.category for memory in memories)
    avg_score = round(mean(score_series), 2) if score_series else 0
    avg_duration_ms = round(mean([summary['duration_ms'] for summary in run_summaries]), 0) if run_summaries else 0
    reflection_rate = round((sum(1 for run in runs if any(trace.role == 'reflector' for trace in run.traces)) / len(runs)) * 100, 0) if runs else 0

    return {
        'config': config_status(),
        'stats': {
            'total_runs': len(runs),
            'memory_count': len(memories),
            'avg_score': avg_score,
            'avg_duration_ms': int(avg_duration_ms),
            'reflection_rate': int(reflection_rate),
            'trace_volume': total_traces,
        },
        'recent_runs': run_summaries,
        'memories': [
            {
                'id': memory.id,
                'content': memory.content,
                'category': memory.category,
                'importance': memory.importance,
                'created_at': memory.created_at,
            }
            for memory in memories
        ],
        'charts': {
            'score_series': score_series,
            'latency_series': latency_series,
            'daily_counts': [{'label': label, 'count': count} for label, count in list(per_day.items())[-7:]],
            'role_distribution': [{'role': role, 'count': count} for role, count in role_distribution.items()],
            'memory_categories': [{'category': category, 'count': count} for category, count in memory_categories.items()],
            'provider_mix': [{'provider': provider, 'count': count} for provider, count in provider_mix.items()],
        },
        'evals': _eval_dashboard(db),
    }


@app.get('/api/runs')
def list_runs(limit: int = 50, db: Session = Depends(get_db)):
    runs = db.query(AgentRun).order_by(AgentRun.created_at.desc()).limit(limit).all()
    return {'runs': [_serialize_run_summary(run) for run in runs]}


@app.get('/api/runs/{run_id}')
def get_run(run_id: int, db: Session = Depends(get_db)):
    run = db.query(AgentRun).filter(AgentRun.id == run_id).first()
    if not run:
        raise HTTPException(status_code=404, detail='Run not found')
    return _serialize_run_detail(run)


@app.get('/api/memories')
def list_memories(limit: int = 20, db: Session = Depends(get_db)):
    memories = db.query(MemoryItem).order_by(MemoryItem.created_at.desc()).limit(limit).all()
    return {
        'memories': [
            {
                'id': memory.id,
                'content': memory.content,
                'category': memory.category,
                'importance': memory.importance,
                'created_at': memory.created_at,
            }
            for memory in memories
        ]
    }


@app.get('/health')
def health():
    cfg = config_status()
    return {'status': 'ok', 'provider': cfg['provider'], 'model_name': cfg['model_name']}

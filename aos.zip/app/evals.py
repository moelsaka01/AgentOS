from __future__ import annotations

import json
from pathlib import Path
from statistics import mean
from typing import Any

from sqlalchemy.orm import Session

from app.agent_runtime import AgentRuntime
from app.llm import DemoLLM, LLMFactory, LLMProviderConfig
from app.models import EvalCase, EvalResult, EvalRun, EvalSuite
from app.tools import ToolRegistry


DATASET_DIR = Path(__file__).resolve().parent.parent / 'evals' / 'datasets'


class EvalSeeder:
    def __init__(self, db: Session):
        self.db = db

    def seed(self) -> None:
        if self.db.query(EvalSuite).count() > 0:
            return
        for path in sorted(DATASET_DIR.glob('*.json')):
            payload = json.loads(path.read_text(encoding='utf-8'))
            suite = EvalSuite(
                name=payload['name'],
                title=payload.get('title', payload['name'].replace('_', ' ').title()),
                description=payload.get('description', ''),
            )
            self.db.add(suite)
            self.db.commit()
            self.db.refresh(suite)
            for item in payload.get('cases', []):
                case = EvalCase(
                    suite_id=suite.id,
                    name=item['name'],
                    goal=item['goal'],
                    eval_type=item.get('eval_type', 'rubric'),
                    difficulty=item.get('difficulty', 'medium'),
                    weight=float(item.get('weight', 1.0)),
                    expected_answer=item.get('expected_answer', ''),
                    rubric_json=json.dumps(item.get('rubric', {})),
                    tags=','.join(item.get('tags', [])),
                )
                self.db.add(case)
            self.db.commit()


class EvalJudge:
    def __init__(self, llm_override: LLMProviderConfig | None = None):
        self.llm = LLMFactory.build(llm_override)

    @staticmethod
    def _normalize(text: str) -> str:
        return ' '.join((text or '').strip().lower().split())

    def _keyword_score(self, answer: str, keywords: list[str]) -> float:
        if not keywords:
            return 0.0
        normalized = self._normalize(answer)
        hits = sum(1 for kw in keywords if self._normalize(kw) in normalized)
        return hits / len(keywords)

    def score_case(self, case: EvalCase, answer: str) -> dict[str, Any]:
        rubric = json.loads(case.rubric_json or '{}')
        keywords = rubric.get('required_keywords', [])
        expected = case.expected_answer or ''
        eval_type = case.eval_type
        keyword_score = self._keyword_score(answer, keywords)

        if eval_type == 'exact_match':
            score = 1.0 if self._normalize(expected) in self._normalize(answer) else keyword_score
            return {
                'score': round(score, 3),
                'passed': score >= 0.95,
                'summary': f'Exact-match benchmark. Expected `{expected}`.',
                'dimensions': {'exact_match': round(score, 3), 'keyword_coverage': round(keyword_score, 3)},
            }

        if eval_type == 'contains_all':
            score = keyword_score
            return {
                'score': round(score, 3),
                'passed': score >= 0.95,
                'summary': 'Keyword containment benchmark.',
                'dimensions': {'keyword_coverage': round(score, 3)},
            }

        if isinstance(self.llm, DemoLLM):
            heuristic = min(0.55 + 0.4 * keyword_score, 0.97)
            dims = {dim: round(heuristic if dim != 'memory_use' else keyword_score, 3) for dim in rubric.get('dimensions', ['correctness', 'clarity'])}
            return {
                'score': round(mean(dims.values()) if dims else heuristic, 3),
                'passed': (mean(dims.values()) if dims else heuristic) >= 0.7,
                'summary': 'Heuristic judge used because no external LLM provider is configured.',
                'dimensions': dims,
            }

        judge_fallback = {
            'score': round(min(0.6 + 0.35 * keyword_score, 0.95), 3),
            'passed': keyword_score >= 0.6,
            'summary': 'Fallback rubric-based evaluation.',
            'dimensions': {dim: round(min(0.6 + 0.35 * keyword_score, 0.95), 3) for dim in rubric.get('dimensions', ['correctness', 'clarity'])},
        }
        judge_prompt = (
            'You are evaluating an AI system benchmark case. '\
            'Return strict JSON with keys score, passed, summary, and dimensions. '\
            'Each dimension score must be between 0 and 1. '\
            f'\n\nCase name: {case.name}'
            f'\nEval type: {eval_type}'
            f'\nExpected behavior: {expected}'
            f'\nRequired keywords: {keywords}'
            f'\nDimension names: {rubric.get("dimensions", ["correctness", "clarity"])}'
            f'\n\nCandidate answer:\n{answer}'
        )
        result = self.llm.generate_json('critic', case.goal, judge_prompt, judge_fallback)
        dims = result.get('dimensions', {}) or {}
        score = float(result.get('score', mean(dims.values()) if dims else 0.0))
        return {
            'score': round(max(0.0, min(score, 1.0)), 3),
            'passed': bool(result.get('passed', score >= 0.75)),
            'summary': str(result.get('summary', 'LLM judge evaluation completed.')),
            'dimensions': {k: round(float(v), 3) for k, v in dims.items()},
        }


class BenchmarkRunner:
    def __init__(self, db: Session, llm_override: LLMProviderConfig | None = None):
        self.db = db
        self.runtime = AgentRuntime(db, llm_override)
        self.tools = ToolRegistry(db)
        self.judge = EvalJudge(llm_override)

    def run_suite(self, suite_name: str) -> EvalRun:
        suite = self.db.query(EvalSuite).filter(EvalSuite.name == suite_name).first()
        if not suite:
            raise ValueError(f'Unknown suite: {suite_name}')
        run = EvalRun(
            suite_name=suite.name,
            status='running',
            provider=self.runtime.llm.provider_name,
            model_name=self.runtime.llm.model_name,
            total_cases=len(suite.cases),
        )
        self.db.add(run)
        self.db.commit()
        self.db.refresh(run)

        for case in suite.cases:
            rubric = json.loads(case.rubric_json or '{}')
            for setup_memory in rubric.get('setup_memories', []):
                self.tools.memory_write(setup_memory, category='eval_setup', importance=0.95)
            agent_run = self.runtime.run_goal(case.goal)
            judged = self.judge.score_case(case, agent_run.final_answer)
            result = EvalResult(
                eval_run_id=run.id,
                eval_case_id=case.id,
                agent_run_id=agent_run.id,
                score=float(judged['score']),
                passed=1 if judged['passed'] else 0,
                latency_ms=max(0, int((agent_run.updated_at - agent_run.created_at).total_seconds() * 1000)),
                judge_summary=judged['summary'],
                dimension_scores_json=json.dumps(judged['dimensions']),
            )
            self.db.add(result)
            self.db.commit()

        results = self.db.query(EvalResult).filter(EvalResult.eval_run_id == run.id).all()
        run.aggregate_score = round(mean([item.score for item in results]), 3) if results else 0.0
        run.pass_rate = round((sum(item.passed for item in results) / len(results)) * 100, 1) if results else 0.0
        run.status = 'completed'
        self.db.commit()
        self.db.refresh(run)
        return run


def serialize_eval_run(run: EvalRun) -> dict[str, Any]:
    results = run.results or []
    suite_scores = []
    for result in results:
        dims = json.loads(result.dimension_scores_json or '{}')
        suite_scores.append(
            {
                'id': result.id,
                'case_name': result.eval_case.name if result.eval_case else f'case-{result.eval_case_id}',
                'score': round(float(result.score), 3),
                'passed': bool(result.passed),
                'latency_ms': result.latency_ms,
                'judge_summary': result.judge_summary,
                'dimensions': dims,
                'agent_run_id': result.agent_run_id,
            }
        )
    return {
        'id': run.id,
        'suite_name': run.suite_name,
        'status': run.status,
        'provider': run.provider,
        'model_name': run.model_name,
        'aggregate_score': round(float(run.aggregate_score), 3),
        'pass_rate': round(float(run.pass_rate), 1),
        'total_cases': run.total_cases,
        'created_at': run.created_at,
        'updated_at': run.updated_at,
        'results': suite_scores,
    }

from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field


class LLMOverrideRequest(BaseModel):
    provider: str | None = Field(default=None, max_length=40)
    model_name: str | None = Field(default=None, max_length=200)
    api_key: str | None = Field(default=None, max_length=500)
    base_url: str | None = Field(default=None, max_length=300)


class GoalRequest(BaseModel):
    goal: str = Field(..., min_length=3, max_length=5000)
    auto_eval: bool = False
    eval_suite_name: str | None = Field(default=None, max_length=100)
    depth_mode: str | None = Field(default=None, max_length=20)
    llm_override: LLMOverrideRequest | None = None


class GoalResponse(BaseModel):
    run_id: int
    status: str
    final_answer: str
    critic_score: float
    critic_feedback: str
    eval_runs: list[dict] = []


class EvalRunRequest(BaseModel):
    suite_name: str = Field(..., min_length=2, max_length=100)
    llm_override: LLMOverrideRequest | None = None


class MemoryCreate(BaseModel):
    content: str
    category: str = 'general'
    importance: float = 0.5


class MemoryRead(BaseModel):
    id: int
    content: str
    category: str
    importance: float
    created_at: datetime

    class Config:
        from_attributes = True

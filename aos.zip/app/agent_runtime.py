from __future__ import annotations

import json
from datetime import datetime

from sqlalchemy.orm import Session

from app.config import settings
from app.llm import DemoLLM, LLMFactory, LLMProviderConfig
from app.models import AgentRun, TraceEvent
from app.tools import ToolRegistry


class AgentRuntime:
    def __init__(self, db: Session, llm_override: LLMProviderConfig | None = None):
        self.db = db
        self.llm = LLMFactory.build(llm_override)
        self.tools = ToolRegistry(db)

    def _trace(self, run: AgentRun, role: str, event_type: str, content: str) -> None:
        event = TraceEvent(run_id=run.id, role=role, event_type=event_type, content=content)
        self.db.add(event)
        run.updated_at = datetime.utcnow()
        self.db.commit()

    @staticmethod
    def _resolve_depth(goal: str, depth_mode: str | None = None) -> str:
        if depth_mode in {'normal', 'deep', 'exhaustive'}:
            return depth_mode
        text = goal.lower()
        exhaustive_markers = [
            'iterate', 'compare all', 'version 1', 'version 2', 'version 3',
            'simulate', 'failure modes', 'tradeoffs', 'refine', 'critique',
        ]
        deep_markers = [
            'architecture', 'roadmap', 'enterprise', 'regulated', 'evaluation',
            'benchmark', 'observability', 'reliability', 'scalability',
        ]
        if any(marker in text for marker in exhaustive_markers):
            return 'exhaustive'
        if any(marker in text for marker in deep_markers):
            return 'deep'
        return settings.runtime_depth_default if settings.runtime_depth_default in {'normal', 'deep', 'exhaustive'} else 'deep'

    @staticmethod
    def _depth_profile(depth: str) -> dict[str, int]:
        if depth == 'normal':
            return {'plan_rounds': 1, 'research_passes': 1, 'refinement_rounds': 1}
        if depth == 'exhaustive':
            return {
                'plan_rounds': max(2, settings.deep_plan_expansion_rounds + 1),
                'research_passes': max(2, settings.deep_research_passes + 1),
                'refinement_rounds': max(3, settings.max_reflection_rounds),
            }
        return {
            'plan_rounds': max(1, settings.deep_plan_expansion_rounds),
            'research_passes': max(1, settings.deep_research_passes),
            'refinement_rounds': max(settings.force_min_refinement_rounds, 2),
        }

    def run_goal(self, goal: str, depth_mode: str | None = None) -> AgentRun:
        depth = self._resolve_depth(goal, depth_mode)
        profile = self._depth_profile(depth)

        run = AgentRun(goal=goal, status='running', provider=self.llm.provider_name, model_name=self.llm.model_name, depth_mode=depth)
        self.db.add(run)
        self.db.commit()
        self.db.refresh(run)

        self._trace(run, 'planner', 'runtime_profile', json.dumps({'depth_mode': depth, **profile}, indent=2))

        memory_result = self.tools.memory_search(goal, limit=8 if depth != 'normal' else 5)
        self._trace(run, 'memory', 'retrieval_primary', memory_result['output'])
        memory_lines = [m['content'] for m in memory_result.get('matches', [])]

        plan_versions: list[str] = []
        planner_seed_prompt = (
            'Create a recruiter-ready execution plan for this goal. '
            'Return numbered steps, success criteria, and explicit checkpoints for planning, research, execution, critique, and synthesis. '
            f'\n\nDepth mode: {depth}\nMemory context:\n{memory_result["output"]}'
        )
        initial_plan = self.llm.generate('planner', goal, planner_seed_prompt).text
        plan_versions.append(initial_plan)
        self._trace(run, 'planner', 'plan_v1', initial_plan)

        for round_idx in range(2, profile['plan_rounds'] + 1):
            expansion_prompt = (
                f'Expand and stress-test the existing plan for round {round_idx}. '
                'Add more detail, risks, tradeoffs, dependencies, checkpoints, and validation steps. '
                'Preserve the original structure but make it deeper and more demanding.'
                f'\n\nCurrent best plan:\n{plan_versions[-1]}'
            )
            expanded = self.llm.generate('planner', goal, expansion_prompt).text
            plan_versions.append(expanded)
            self._trace(run, 'planner', f'plan_v{round_idx}', expanded)

        run.plan_text = plan_versions[-1]
        self.db.commit()

        tool_observations: list[str] = []
        calc_result = self.tools.calculator(goal)
        if calc_result:
            tool_observations.append(calc_result['output'])
            self._trace(run, 'executor', 'tool_used', calc_result['output'])

        if any(token in goal.lower() for token in ['remember', 'save this', 'store this']):
            write_result = self.tools.memory_write(goal, category='user_goal', importance=0.9)
            tool_observations.append(write_result['output'])
            self._trace(run, 'memory', 'write', write_result['output'])

        research_snapshots: list[str] = []
        for pass_idx in range(1, profile['research_passes'] + 1):
            if pass_idx == 1:
                current_memory = memory_result['output']
            else:
                refined_query = (
                    f'{goal}\n\nUse this latest plan and research to search for missing constraints, risks, and decisions:\n'
                    f'{plan_versions[-1]}\n\nPrevious synthesis:\n{research_snapshots[-1]}'
                )
                refined_memory = self.tools.memory_search(refined_query, limit=8 if depth != 'normal' else 5)
                current_memory = refined_memory['output']
                for match in refined_memory.get('matches', []):
                    if match['content'] not in memory_lines:
                        memory_lines.append(match['content'])
                self._trace(run, 'memory', f'retrieval_refined_{pass_idx}', current_memory)

            prior_research = '\n\n'.join(research_snapshots) if research_snapshots else 'No prior synthesis yet.'
            researcher_prompt = (
                f'You are the researcher pass {pass_idx} of {profile["research_passes"]}. '
                'Synthesize the strongest context for execution. Focus on constraints, architecture choices, risk factors, missing assumptions, and evidence from memory and tools. '
                'If this is not the first pass, improve on earlier research and close the gaps.'
                f'\n\nPlan:\n{plan_versions[-1]}\n\nMemory:\n{current_memory}\n\nTools:\n{chr(10).join(tool_observations) or "No tools used."}\n\nPrior research:\n{prior_research}'
            )
            research_text = self.llm.generate('researcher', goal, researcher_prompt).text
            research_snapshots.append(research_text)
            self._trace(run, 'researcher', f'context_synthesized_{pass_idx}', research_text)

        draft_history: list[str] = []
        critique_history: list[dict[str, object]] = []
        current_draft = ''

        executor_prompt = (
            'Produce a strong draft answer for the user. Make it detailed, high-signal, structured, and decision-oriented. '
            'Use sections, tradeoffs, and concrete recommendations. '
            f'\n\nDepth mode: {depth}\nFinal plan:\n{plan_versions[-1]}\n\nRelevant memory:\n' + ('\n'.join(memory_lines) or 'None') +
            '\n\nResearch synthesis:\n' + '\n\n'.join(research_snapshots) +
            '\n\nTool observations:\n' + ('\n'.join(tool_observations) or 'No tools used.')
        )
        current_draft = self.llm.generate('executor', goal, executor_prompt).text
        draft_history.append(current_draft)
        self._trace(run, 'executor', 'draft_answer_v1', current_draft)

        latest_score = 0.0
        latest_feedback = 'No feedback returned.'

        critic_fallback = {
            'score': 0.82,
            'feedback': 'Answer is acceptable but should be more specific, better structured, and stronger on tradeoffs.',
            'strengths': ['Structure is reasonable'],
            'weaknesses': ['Needs sharper tradeoffs', 'Needs stronger risk discussion'],
            'next_actions': ['Improve specificity', 'Add risk mitigation', 'Tighten final recommendation'],
        }

        for round_idx in range(1, profile['refinement_rounds'] + 1):
            critic_prompt = (
                'Score the draft from 0 to 1 and return JSON with keys score, feedback, strengths, weaknesses, and next_actions. '
                'Judge clarity, correctness, structure, usefulness, depth, tradeoffs, and whether the answer feels senior-level.'
                f'\n\nDepth mode: {depth}\nRound: {round_idx}/{profile["refinement_rounds"]}\nDraft answer:\n{current_draft}'
            )
            critic_json = self.llm.generate_json('critic', goal, critic_prompt, critic_fallback)
            latest_score = float(critic_json.get('score', 0.82))
            latest_feedback = str(critic_json.get('feedback', 'No feedback returned.'))
            strengths = critic_json.get('strengths', [])
            weaknesses = critic_json.get('weaknesses', [])
            next_actions = critic_json.get('next_actions', [])
            critique_payload = {
                'round': round_idx,
                'score': latest_score,
                'feedback': latest_feedback,
                'strengths': strengths,
                'weaknesses': weaknesses,
                'next_actions': next_actions,
            }
            critique_history.append(critique_payload)
            self._trace(run, 'critic', f'critique_round_{round_idx}', json.dumps(critique_payload, indent=2))

            must_continue = round_idx < max(profile['refinement_rounds'], settings.force_min_refinement_rounds)
            if not must_continue and latest_score >= 0.93:
                break

            reflection_prompt = (
                'Improve the draft using the critique. Make it more detailed, more concrete, and more impressive to a recruiter or engineering leader. '
                'Address every weakness and next action. Preserve what is already strong while deepening the quality.'
                f'\n\nCritique:\n{json.dumps(critique_payload, indent=2)}\n\nOriginal draft:\n{current_draft}'
            )
            refined = self.llm.generate('reflector', goal, reflection_prompt).text
            current_draft = refined
            draft_history.append(refined)
            self._trace(run, 'reflector', f'revision_round_{round_idx}', refined)

        synthesis_prompt = (
            'Create the final answer by synthesizing the best ideas from all draft versions, the final plan, the research passes, and the critique history. '
            'The final answer should feel polished, concise for the amount of complexity, and executive-quality. '
            'Keep the strongest structure, add a clear recommendation, and preserve critical tradeoffs and risk handling.'
            f'\n\nPlan versions:\n{chr(10).join(plan_versions)}\n\nResearch passes:\n{chr(10).join(research_snapshots)}\n\nDraft history:\n{chr(10).join(draft_history)}\n\nCritique history:\n{json.dumps(critique_history, indent=2)}'
        )
        final_answer = self.llm.generate('executor', goal, synthesis_prompt).text
        self._trace(run, 'executor', 'final_synthesis', final_answer)

        run.final_answer = final_answer
        run.critic_score = round(min(max(latest_score, 0.0), 0.99), 2)
        run.critic_feedback = latest_feedback
        run.status = 'completed'
        run.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(run)

        if not isinstance(self.llm, DemoLLM):
            summary_text = (
                f'Goal: {goal}\nProvider: {run.provider}\nModel: {run.model_name}\n'
                f'Depth mode: {depth}\nOutcome summary: {final_answer[:1000]}'
            )
            self.tools.memory_write(summary_text, category='run_summary', importance=0.75)

        return run

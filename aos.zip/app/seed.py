from __future__ import annotations

from sqlalchemy.orm import Session

from app.models import MemoryItem


def seed_memories(db: Session) -> None:
    existing = db.query(MemoryItem).count()
    if existing > 0:
        return

    starter_memories = [
        MemoryItem(content="AgentOS is a memory-augmented self-improving agent runtime.", category="project", importance=0.9),
        MemoryItem(content="Planner, executor, critic, and reflector are the main runtime roles.", category="architecture", importance=0.8),
        MemoryItem(content="Observability is important for tracing agent failures and tool usage.", category="engineering", importance=0.8),
    ]
    db.add_all(starter_memories)
    db.commit()

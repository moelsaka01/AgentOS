from __future__ import annotations

from sqlalchemy.orm import Session

from app.llm import extract_math_expression, safe_eval_expression
from app.models import MemoryItem
from app.vector_memory import VectorMemoryStore


class ToolResult(dict):
    pass


class ToolRegistry:
    def __init__(self, db: Session):
        self.db = db
        self.vector_store = VectorMemoryStore()

    def calculator(self, goal: str) -> ToolResult | None:
        expr = extract_math_expression(goal)
        if not expr:
            return None
        try:
            value = safe_eval_expression(expr)
            return ToolResult(name='calculator', output=f'Expression `{expr}` = {value}')
        except Exception as exc:
            return ToolResult(name='calculator', output=f'Could not evaluate expression `{expr}`: {exc}')

    def memory_search(self, goal: str, limit: int = 5) -> ToolResult:
        matches = self.vector_store.search(goal, limit=limit)
        if not matches:
            return ToolResult(name='memory_search', output='No related memories found.', matches=[])
        formatted = []
        for match in matches:
            meta = match['metadata']
            score = 1.0 - min(match['distance'], 1.0)
            formatted.append(
                f"[{meta.get('category', 'general')}] {match['content']} (relevance {score:.2f})"
            )
        return ToolResult(name='memory_search', output=' | '.join(formatted), matches=matches)

    def memory_write(self, content: str, category: str = 'learned', importance: float = 0.7) -> ToolResult:
        item = MemoryItem(content=content, category=category, importance=importance)
        self.db.add(item)
        self.db.commit()
        self.db.refresh(item)
        vector_id = f'memory-{item.id}'
        item.vector_id = vector_id
        self.db.commit()
        self.vector_store.add_memory(
            vector_id=vector_id,
            content=item.content,
            metadata={'memory_id': item.id, 'category': item.category, 'importance': item.importance},
        )
        return ToolResult(name='memory_write', output=f'Saved memory #{item.id}: {item.content}')

    def sync_existing_memories(self) -> None:
        items = self.db.query(MemoryItem).order_by(MemoryItem.created_at.asc()).all()
        for item in items:
            vector_id = item.vector_id or f'memory-{item.id}'
            if not item.vector_id:
                item.vector_id = vector_id
                self.db.commit()
            self.vector_store.add_memory(
                vector_id=vector_id,
                content=item.content,
                metadata={'memory_id': item.id, 'category': item.category, 'importance': item.importance},
            )

from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass
class Settings:
    app_name: str = os.getenv('AGENT_NAME', 'AgentOS')
    database_url: str = os.getenv('DATABASE_URL', 'sqlite:///./data/agentos.db')
    provider: str = os.getenv('LLM_PROVIDER', 'auto').lower()
    groq_api_key: str = os.getenv('GROQ_API_KEY', '').strip()
    groq_model: str = os.getenv('GROQ_MODEL', 'openai/gpt-oss-20b')
    openai_api_key: str = os.getenv('OPENAI_API_KEY', '').strip()
    openai_model: str = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
    temperature: float = float(os.getenv('LLM_TEMPERATURE', '0.2'))
    max_tokens: int = int(os.getenv('LLM_MAX_TOKENS', '1400'))
    chroma_dir: str = os.getenv('CHROMA_DIR', './data/chroma')
    runtime_depth_default: str = os.getenv('AOS_RUNTIME_DEPTH', 'deep').lower()
    force_min_refinement_rounds: int = int(os.getenv('AOS_MIN_REFINEMENT_ROUNDS', '2'))
    deep_plan_expansion_rounds: int = int(os.getenv('AOS_PLAN_EXPANSION_ROUNDS', '2'))
    deep_research_passes: int = int(os.getenv('AOS_RESEARCH_PASSES', '2'))
    max_reflection_rounds: int = int(os.getenv('AOS_MAX_REFLECTION_ROUNDS', '3'))

    @property
    def active_provider(self) -> str:
        if self.provider in {'groq', 'openai', 'demo'}:
            return self.provider
        if self.groq_api_key:
            return 'groq'
        if self.openai_api_key:
            return 'openai'
        return 'demo'


settings = Settings()

const PROMPT_LIBRARY = {
  architecture: {
    title: 'Architecture',
    text: 'Design a production-ready multi-agent AI system for enterprise document analysis. Include memory, tool usage, evaluation loops, failure handling, architecture, data flow, and tradeoffs.',
    guidance: 'Great for showing planning depth, role coordination, and system design tradeoffs.',
  },
  memory: {
    title: 'Memory',
    text: 'Remember that our system prioritizes reliability over speed and targets enterprise clients in regulated industries. Then propose the best architecture based on those priorities.',
    guidance: 'Great for showing vector memory retrieval and personalized reasoning.',
  },
  cost: {
    title: 'Cost',
    text: 'Estimate the monthly cost of running an AI system with 50,000 daily users, 8 API calls per user at $0.001 per call, and propose optimizations.',
    guidance: 'Great for tool usage, quantitative reasoning, and product tradeoffs.',
  },
  eval: {
    title: 'Evaluation',
    text: 'Design an evaluation system for multi-agent AI workflows with benchmark suites, scorecards, failure analysis, and regression tracking.',
    guidance: 'Great for benchmark lab demos and recruiter-facing AI systems engineering.',
  },
  reflection: {
    title: 'Reflection',
    text: 'Propose a rollout plan for an AI SaaS product, then critique your plan, identify weaknesses, and improve it.',
    guidance: 'Great for showing critic and reflector behavior.',
  },
  incident: {
    title: 'Incident',
    text: 'Analyze why an autonomous agent platform failed in production, identify likely root causes, propose monitoring, rollback, and recovery strategies, and define next actions.',
    guidance: 'Great for showing observability thinking and operational maturity.',
  },
};

const ROLE_META = {
  planner: { icon: '◆', label: 'Planner' },
  researcher: { icon: '◌', label: 'Researcher' },
  executor: { icon: '▶', label: 'Executor' },
  critic: { icon: '✦', label: 'Critic' },
  reflector: { icon: '↺', label: 'Reflector' },
  memory: { icon: '⬢', label: 'Memory' },
};

const LIVE_SCENARIOS = {
  concise: [
    ['planner', 'Breaking the goal into a compact plan.'],
    ['researcher', 'Checking semantic memory and prior context.'],
    ['executor', 'Drafting the answer and assembling the final response.'],
    ['critic', 'Scoring the output for quality and risk.'],
  ],
  advanced: [
    ['planner', 'Breaking the goal into milestones, dependencies, and success criteria.'],
    ['researcher', 'Searching long-term memory and recent run traces for reusable context.'],
    ['executor', 'Drafting the main response, tool outputs, and product tradeoffs.'],
    ['critic', 'Evaluating completeness, clarity, and production realism.'],
    ['reflector', 'Applying a final improvement pass if the critic surfaces gaps.'],
  ],
  deep: [
    ['planner', 'Constructing a deep execution DAG with role boundaries and checkpoints.'],
    ['researcher', 'Collecting memory, benchmark patterns, and prior failures that matter.'],
    ['executor', 'Generating a detailed answer with architecture, tradeoffs, and operating model.'],
    ['critic', 'Stress-testing the answer for depth, correctness, and recruiter signal.'],
    ['reflector', 'Revising structure, tightening weak sections, and clarifying next steps.'],
    ['executor', 'Producing a polished final version with stronger recommendations.'],
  ],
};

const state = {
  dashboard: null,
  runs: [],
  memories: [],
  evals: null,
  selectedRunId: Number(document.body.dataset.initialRunId || 0) || null,
  selectedRun: null,
  traceFilter: 'all',
  runSearch: '',
  complexity: 'advanced',
  liveInterval: null,
  liveTick: 0,
  runtimeDepth: 'deep',
};

const els = {
  providerBadge: document.getElementById('provider-badge'),
  modelBadge: document.getElementById('model-badge'),
  refresh: document.getElementById('refresh-dashboard'),
  goalForm: document.getElementById('goal-form'),
  goalInput: document.getElementById('goal-input'),
  runButton: document.getElementById('run-button'),
  runProgress: document.getElementById('run-progress'),
  liveRunTitle: document.getElementById('live-run-title'),
  liveRunCopy: document.getElementById('live-run-copy'),
  liveRunLog: document.getElementById('live-run-log'),
  liveAgentMap: document.getElementById('live-agent-map'),
  metricTotalRuns: document.getElementById('metric-total-runs'),
  metricAvgScore: document.getElementById('metric-avg-score'),
  metricAvgDuration: document.getElementById('metric-avg-duration'),
  metricReflectionRate: document.getElementById('metric-reflection-rate'),
  metricTotalRunsState: document.getElementById('metric-total-runs-state'),
  metricAvgScoreState: document.getElementById('metric-avg-score-state'),
  metricAvgDurationState: document.getElementById('metric-avg-duration-state'),
  metricReflectionRateState: document.getElementById('metric-reflection-rate-state'),
  metricTotalRunsCaption: document.getElementById('metric-total-runs-caption'),
  metricAvgScoreCaption: document.getElementById('metric-avg-score-caption'),
  metricAvgDurationCaption: document.getElementById('metric-avg-duration-caption'),
  metricReflectionRateCaption: document.getElementById('metric-reflection-rate-caption'),
  metricCardRuns: document.getElementById('metric-card-runs'),
  metricCardScore: document.getElementById('metric-card-score'),
  metricCardDuration: document.getElementById('metric-card-duration'),
  metricCardReflection: document.getElementById('metric-card-reflection'),
  metricRunsSpark: document.getElementById('metric-total-runs-spark'),
  metricScoreSpark: document.getElementById('metric-avg-score-spark'),
  metricDurationSpark: document.getElementById('metric-avg-duration-spark'),
  metricReflectionSpark: document.getElementById('metric-reflection-rate-spark'),
  scoreChart: document.getElementById('score-chart'),
  latencyChart: document.getElementById('latency-chart'),
  runsChart: document.getElementById('runs-chart'),
  providerChart: document.getElementById('provider-chart'),
  roleChart: document.getElementById('role-chart'),
  traceVolumePill: document.getElementById('trace-volume-pill'),
  runSearch: document.getElementById('run-search'),
  runsList: document.getElementById('runs-list'),
  detailTitle: document.getElementById('detail-title'),
  detailEmpty: document.getElementById('detail-empty'),
  detailContent: document.getElementById('detail-content'),
  detailActions: document.getElementById('detail-actions'),
  openRunLink: document.getElementById('open-run-link'),
  copyRunJson: document.getElementById('copy-run-json'),
  runStatus: document.getElementById('run-status'),
  runProvider: document.getElementById('run-provider'),
  runScore: document.getElementById('run-score'),
  runLatency: document.getElementById('run-latency'),
  runTraces: document.getElementById('run-traces'),
  runDepth: document.getElementById('run-depth'),
  runGoal: document.getElementById('run-goal'),
  runPlan: document.getElementById('run-plan'),
  runAnswer: document.getElementById('run-answer'),
  agentsGrid: document.getElementById('agents-grid'),
  traceMap: document.getElementById('trace-map'),
  traceFilters: document.getElementById('trace-filters'),
  traceTimeline: document.getElementById('trace-timeline'),
  memoryList: document.getElementById('memory-list'),
  memoryCountPill: document.getElementById('memory-count-pill'),
  evalSuiteCount: document.getElementById('eval-suite-count'),
  evalRunCount: document.getElementById('eval-run-count'),
  evalAvgScore: document.getElementById('eval-avg-score'),
  evalAvgPassRate: document.getElementById('eval-avg-pass-rate'),
  evalSuiteGrid: document.getElementById('eval-suite-grid'),
  evalScoreChart: document.getElementById('eval-score-chart'),
  evalPassChart: document.getElementById('eval-pass-chart'),
  evalSuiteMix: document.getElementById('eval-suite-mix'),
  evalRunsList: document.getElementById('eval-runs-list'),
  evalFailures: document.getElementById('eval-failures'),
  autoEvalToggle: document.getElementById('auto-eval-toggle'),
  defaultSuiteSelect: document.getElementById('default-suite-select'),
  depthModeSelect: document.getElementById('depth-mode-select'),
  depthWarning: document.getElementById('depth-warning'),
  runBenchmarkButton: document.getElementById('run-benchmark-button'),
  evalLastSuite: document.getElementById('eval-last-suite'),
  lastBenchmarkBanner: document.getElementById('last-benchmark-banner'),
  lastBenchmarkTitle: document.getElementById('last-benchmark-title'),
  lastBenchmarkStatus: document.getElementById('last-benchmark-status'),
  lastBenchmarkCopy: document.getElementById('last-benchmark-copy'),
  lastBenchmarkSuite: document.getElementById('last-benchmark-suite'),
  lastBenchmarkScore: document.getElementById('last-benchmark-score'),
  lastBenchmarkPassRate: document.getElementById('last-benchmark-pass-rate'),
  lastBenchmarkCases: document.getElementById('last-benchmark-cases'),
  lastBenchmarkProvider: document.getElementById('last-benchmark-provider'),
  lastBenchmarkTime: document.getElementById('last-benchmark-time'),
  promptTemplateSelect: document.getElementById('prompt-template-select'),
  templateTags: document.getElementById('template-tags'),
  complexityToggle: document.getElementById('complexity-toggle'),
  composerGuidance: document.getElementById('composer-guidance'),
  promptCountPill: document.getElementById('prompt-count-pill'),
  controlSystemHealth: document.getElementById('control-system-health'),
  controlTotalRuns: document.getElementById('control-total-runs'),
  controlRunCopy: document.getElementById('control-run-copy'),
  controlAvgScore: document.getElementById('control-avg-score'),
  controlScoreCopy: document.getElementById('control-score-copy'),
  controlLastBenchmark: document.getElementById('control-last-benchmark'),
  controlBenchmarkCopy: document.getElementById('control-benchmark-copy'),
  liveRoleBadges: document.getElementById('live-role-badges'),
  providerSelect: document.getElementById('provider-select'),
  modelInput: document.getElementById('model-input'),
  apiKeyInput: document.getElementById('api-key-input'),
  baseUrlInput: document.getElementById('base-url-input'),
  baseUrlWrap: document.getElementById('base-url-wrap'),
};

function escapeHtml(str = '') {
  return String(str).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

function formatDuration(ms) {
  const value = Number(ms || 0);
  if (value < 1000) return `${Math.round(value)} ms`;
  const seconds = value / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)} s`;
  const minutes = seconds / 60;
  if (minutes < 60) return `${minutes.toFixed(1)} min`;
  const hours = minutes / 60;
  if (hours < 24) return `${hours.toFixed(1)} hr`;
  const days = hours / 24;
  if (days < 30) return `${days.toFixed(1)} d`;
  const months = days / 30;
  if (months < 12) return `${months.toFixed(1)} mo`;
  const years = months / 12;
  return `${years.toFixed(1)} yr`;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(1)}%`;
}

function getAutoEvalEnabled() {
  return localStorage.getItem('aos:autoEval') === '1';
}

function setAutoEvalEnabled(value) {
  localStorage.setItem('aos:autoEval', value ? '1' : '0');
}

function getDefaultSuiteName() {
  return localStorage.getItem('aos:defaultSuite') || '';
}

function setDefaultSuiteName(value) {
  if (value) localStorage.setItem('aos:defaultSuite', value);
}


function getLLMOverride() {
  const provider = els.providerSelect?.value || 'local';
  const modelName = els.modelInput?.value?.trim() || '';
  const apiKey = els.apiKeyInput?.value?.trim() || '';
  const baseUrl = els.baseUrlInput?.value?.trim() || '';
  return {
    provider,
    model_name: modelName || null,
    api_key: apiKey || null,
    base_url: baseUrl || null,
  };
}

function applyProviderVisibility() {
  const provider = els.providerSelect?.value || 'local';
  const needsBaseUrl = provider === 'custom_openai';
  els.baseUrlWrap?.classList.toggle('hidden', !needsBaseUrl);
}

function restoreProviderPrefs() {
  if (els.providerSelect) els.providerSelect.value = localStorage.getItem('aos:provider') || 'local';
  if (els.modelInput) els.modelInput.value = localStorage.getItem('aos:model') || '';
  if (els.apiKeyInput) els.apiKeyInput.value = localStorage.getItem('aos:apiKey') || '';
  if (els.baseUrlInput) els.baseUrlInput.value = localStorage.getItem('aos:baseUrl') || '';
  applyProviderVisibility();
}

function persistProviderPrefs() {
  els.providerSelect?.addEventListener('change', () => {
    localStorage.setItem('aos:provider', els.providerSelect.value);
    applyProviderVisibility();
  });
  els.modelInput?.addEventListener('input', () => localStorage.setItem('aos:model', els.modelInput.value));
  els.apiKeyInput?.addEventListener('input', () => localStorage.setItem('aos:apiKey', els.apiKeyInput.value));
  els.baseUrlInput?.addEventListener('input', () => localStorage.setItem('aos:baseUrl', els.baseUrlInput.value));
}

function getRuntimeDepthMode() {
  return localStorage.getItem('aos:depthMode') || state.runtimeDepth || 'deep';
}

function setRuntimeDepthMode(value) {
  const normalized = ['normal', 'deep', 'exhaustive'].includes(value) ? value : (state.runtimeDepth || 'deep');
  state.runtimeDepth = normalized;
  localStorage.setItem('aos:depthMode', normalized);
  if (els.depthModeSelect) els.depthModeSelect.value = normalized;
  updateDepthWarning(normalized);
}

function formatDepthLabel(value) {
  const normalized = String(value || 'deep').toLowerCase();
  if (normalized === 'normal') return 'Normal';
  if (normalized === 'exhaustive') return 'Exhaustive';
  return 'Deep';
}

function depthBadgeClass(value) {
  const normalized = String(value || 'deep').toLowerCase();
  return `depth-badge ${normalized}`;
}

function updateDepthWarning(value) {
  if (!els.depthWarning) return;
  const exhaustive = String(value || '').toLowerCase() === 'exhaustive';
  els.depthWarning.classList.toggle('hidden', !exhaustive);
  if (els.depthModeSelect) {
    els.depthModeSelect.classList.toggle('exhaustive-selected', exhaustive);
  }
}

async function getJson(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error(`Request failed: ${response.status}`);
  return response.json();
}

function renderLineChart(container, series, label, formatter = (v) => Number(v).toFixed(2)) {
  if (!container) return;
  if (!series?.length) {
    container.innerHTML = '<div class="empty-state">Not enough data yet.</div>';
    return;
  }
  const width = 640;
  const height = 220;
  const padding = 24;
  const max = Math.max(...series, 1);
  const min = Math.min(...series, 0);
  const range = Math.max(max - min, 1);
  const points = series.map((value, index) => {
    const x = padding + (index * ((width - padding * 2) / Math.max(series.length - 1, 1)));
    const y = height - padding - ((value - min) / range) * (height - padding * 2);
    return [x, y, value];
  });
  const polyline = points.map(([x, y]) => `${x},${y}`).join(' ');
  const area = `${padding},${height - padding} ${polyline} ${width - padding},${height - padding}`;
  container.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${label}">
      <defs>
        <linearGradient id="chartFill-${label.replace(/\s+/g, '-')}" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stop-color="rgba(122,163,255,0.55)"></stop>
          <stop offset="100%" stop-color="rgba(122,163,255,0.02)"></stop>
        </linearGradient>
      </defs>
      <polygon fill="url(#chartFill-${label.replace(/\s+/g, '-')})" points="${area}"></polygon>
      <polyline fill="none" stroke="rgba(145,174,255,0.95)" stroke-width="3" points="${polyline}"></polyline>
      ${points.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="4" fill="#dce7ff"></circle>`).join('')}
      <text x="${padding}" y="18">${label}</text>
      <text x="${padding}" y="${height - 8}">${formatter(min)}</text>
      <text x="${width - padding}" y="${padding}" text-anchor="end">${formatter(max)}</text>
    </svg>`;
}

function renderBarChart(container, items, labelKey, valueKey) {
  if (!container) return;
  if (!items?.length) {
    container.innerHTML = '<div class="empty-state">Not enough data yet.</div>';
    return;
  }
  const max = Math.max(...items.map((item) => item[valueKey]), 1);
  container.innerHTML = items.map((item) => `
    <div class="bar-row">
      <div class="bar-label">${escapeHtml(String(item[labelKey]))}</div>
      <div class="bar-track"><span style="width:${(item[valueKey] / max) * 100}%"></span></div>
      <div class="bar-value">${item[valueKey]}</div>
    </div>`).join('');
}

function renderMiniSparkline(container, series, tone = 'blue') {
  if (!container) return;
  if (!series?.length) {
    container.innerHTML = '<div class="empty-state">-</div>';
    return;
  }
  const width = 220;
  const height = 54;
  const padding = 4;
  const max = Math.max(...series, 1);
  const min = Math.min(...series, 0);
  const range = Math.max(max - min, 1);
  const points = series.map((value, index) => {
    const x = padding + (index * ((width - padding * 2) / Math.max(series.length - 1, 1)));
    const y = height - padding - ((value - min) / range) * (height - padding * 2);
    return [x, y];
  });
  const d = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x},${y}`).join(' ');
  const area = `${d} L ${width - padding},${height - padding} L ${padding},${height - padding} Z`;
  const colors = {
    blue: ['rgba(122,163,255,0.94)', 'rgba(122,163,255,0.22)'],
    violet: ['rgba(162,124,255,0.94)', 'rgba(162,124,255,0.22)'],
    green: ['rgba(65,214,170,0.94)', 'rgba(65,214,170,0.22)'],
    amber: ['rgba(240,179,90,0.94)', 'rgba(240,179,90,0.22)'],
  };
  const [stroke, fill] = colors[tone] || colors.blue;
  container.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true">
      <path class="fill" d="${area}" fill="${fill}"></path>
      <path d="${d}" stroke="${stroke}"></path>
    </svg>`;
}

function getMetricStatus(value, type) {
  if (type === 'score') {
    if (value >= 0.9) return ['good', 'strong'];
    if (value >= 0.75) return ['warn', 'mixed'];
    return ['danger', 'needs work'];
  }
  if (type === 'latency') {
    if (value <= 15000) return ['good', 'fast'];
    if (value <= 45000) return ['warn', 'watch'];
    return ['danger', 'slow'];
  }
  if (type === 'reflection') {
    if (value <= 15) return ['good', 'tight'];
    if (value <= 35) return ['warn', 'active'];
    return ['danger', 'heavy'];
  }
  if (type === 'runs') {
    if (value >= 10) return ['good', 'active'];
    if (value >= 4) return ['warn', 'warming'];
    return ['danger', 'light'];
  }
  return ['warn', 'steady'];
}

function applyMetricCard(card, stateEl, captionEl, type, value, caption) {
  const [klass, label] = getMetricStatus(value, type);
  if (card) card.className = card.className.replace(/status-(good|warn|danger)/g, '').trim() + ` status-${klass}`;
  if (stateEl) {
    stateEl.className = 'metric-state';
    stateEl.classList.add(klass);
    stateEl.textContent = label;
  }
  if (captionEl) captionEl.textContent = caption;
}

function renderControlCenter(data) {
  const stats = data.stats;
  const config = data.config;
  if (config?.runtime_depth_default && !localStorage.getItem('aos:depthMode')) {
    state.runtimeDepth = config.runtime_depth_default;
  }
  hydrateDepthSelector(config);
  const override = getLLMOverride();
  const sessionProvider = override.provider && override.provider !== 'local' && override.api_key ? override.provider : config.provider;
  const sessionModel = override.model_name || config.model_name;
  els.providerBadge.textContent = `${sessionProvider.toUpperCase()} runtime`;
  els.modelBadge.textContent = sessionModel;
  els.controlTotalRuns.textContent = String(stats.total_runs);
  els.controlRunCopy.textContent = stats.total_runs ? `${stats.trace_volume} trace events recorded` : 'No executions yet';
  els.controlAvgScore.textContent = Number(stats.avg_score).toFixed(2);
  els.controlScoreCopy.textContent = stats.avg_score >= 0.9 ? 'Quality bar is strong' : stats.avg_score >= 0.75 ? 'Quality is mixed' : 'Quality needs work';
  els.controlSystemHealth.textContent = config.provider === 'demo' ? 'Demo mode' : 'Healthy';
}

function renderMetrics(data) {
  const stats = data.stats;
  const scoreSeries = data.charts.score_series || [];
  const latencySeries = data.charts.latency_series || [];
  const runSeries = (data.charts.daily_counts || []).map((item) => item.count);
  const reflectionSeries = state.runs.map((run) => run.trace_count > 0 ? (run.goal.toLowerCase().includes('critique') || run.goal.toLowerCase().includes('improve') ? 100 : 0) : 0).slice(-12);

  els.metricTotalRuns.textContent = stats.total_runs;
  els.metricAvgScore.textContent = Number(stats.avg_score).toFixed(2);
  els.metricAvgDuration.textContent = formatDuration(stats.avg_duration_ms);
  els.metricReflectionRate.textContent = `${stats.reflection_rate}%`;
  els.traceVolumePill.textContent = `${stats.trace_volume} events`;
  els.memoryCountPill.textContent = `${state.memories.length} memories`;

  applyMetricCard(els.metricCardRuns, els.metricTotalRunsState, els.metricTotalRunsCaption, 'runs', stats.total_runs, stats.total_runs ? 'Execution volume and recent adoption' : 'Run your first workflow');
  applyMetricCard(els.metricCardScore, els.metricAvgScoreState, els.metricAvgScoreCaption, 'score', stats.avg_score, stats.avg_score >= 0.9 ? 'Quality is strong across recent runs' : 'Watch quality drift over time');
  applyMetricCard(els.metricCardDuration, els.metricAvgDurationState, els.metricAvgDurationCaption, 'latency', stats.avg_duration_ms, stats.avg_duration_ms <= 15000 ? 'Latency is under control' : 'This may feel slow to end users');
  applyMetricCard(els.metricCardReflection, els.metricReflectionRateState, els.metricReflectionRateCaption, 'reflection', stats.reflection_rate, stats.reflection_rate ? 'Critic triggered follow-up improvements' : 'Most runs complete in one pass');

  renderMiniSparkline(els.metricRunsSpark, runSeries.length ? runSeries : [0], 'blue');
  renderMiniSparkline(els.metricScoreSpark, scoreSeries.length ? scoreSeries : [0], 'violet');
  renderMiniSparkline(els.metricDurationSpark, latencySeries.length ? latencySeries : [0], 'green');
  renderMiniSparkline(els.metricReflectionSpark, reflectionSeries.length ? reflectionSeries : [0], 'amber');
}

function filteredRuns() {
  const query = state.runSearch.trim().toLowerCase();
  if (!query) return state.runs;
  return state.runs.filter((run) => run.goal.toLowerCase().includes(query));
}

function renderRuns() {
  const runs = filteredRuns();
  if (!runs.length) {
    els.runsList.className = 'runs-list empty-state';
    els.runsList.innerHTML = 'No runs match your filter yet.';
    return;
  }
  els.runsList.className = 'runs-list';
  els.runsList.innerHTML = runs.map((run) => `
    <article class="run-card ${state.selectedRunId === run.id ? 'active' : ''}" data-run-id="${run.id}">
      <div class="run-meta"><span class="status-pill">${escapeHtml(run.status)}</span><span class="${depthBadgeClass(run.depth_mode)}">${escapeHtml(formatDepthLabel(run.depth_mode))}</span><span>${formatDate(run.created_at)}</span></div>
      <h4>Run #${run.id}</h4>
      <p>${escapeHtml(run.goal_preview)}</p>
      <div class="run-meta footer"><span>${escapeHtml((run.provider || 'demo').toUpperCase())}</span><span>Score ${Number(run.critic_score).toFixed(2)}</span><span>${formatDuration(run.duration_ms)}</span></div>
    </article>`).join('');
  document.querySelectorAll('.run-card').forEach((card) => {
    card.addEventListener('click', () => selectRun(Number(card.dataset.runId)));
  });
}

function renderMemories() {
  if (!state.memories.length) {
    els.memoryList.innerHTML = '<div class="empty-state">No memories yet.</div>';
    return;
  }
  els.memoryList.innerHTML = state.memories.map((memory) => `
    <article class="memory-card">
      <div class="memory-top"><span class="memory-category">${escapeHtml(memory.category)}</span><span class="memory-importance">Importance ${Number(memory.importance || 0).toFixed(2)}</span></div>
      <p>${escapeHtml(memory.content)}</p>
      <span class="memory-time">${formatDate(memory.created_at)}</span>
    </article>`).join('');
}

function renderAgentPanels() {
  const panels = state.selectedRun?.agent_panels;
  if (!panels) {
    els.agentsGrid.innerHTML = '';
    return;
  }
  const order = ['planner', 'researcher', 'executor', 'critic', 'reflector', 'memory'];
  els.agentsGrid.innerHTML = order.map((role, index) => {
    const panel = panels[role];
    const meta = ROLE_META[role] || { icon: '•', label: role };
    const open = index === 0 ? 'open' : '';
    const status = panel.count ? 'complete' : 'idle';
    const preview = panel.latest_content.length > 160 ? `${panel.latest_content.slice(0, 160)}…` : panel.latest_content;
    return `
      <article class="agent-card">
        <details ${open}>
          <summary>
            <div class="agent-panel-head">
              <div class="agent-panel-left">
                <div class="agent-icon">${meta.icon}</div>
                <div>
                  <div class="agent-role">${escapeHtml(meta.label)}</div>
                  <div class="agent-meta">${panel.count} event${panel.count === 1 ? '' : 's'}</div>
                </div>
              </div>
              <span class="pill ${status === 'complete' ? 'success' : ''}">${escapeHtml(panel.latest_event)}</span>
            </div>
          </summary>
          <div class="agent-body">
            <p class="agent-panel-preview">${escapeHtml(preview)}</p>
            <div class="agent-stats"><span>${escapeHtml(panel.role)}</span><span>${panel.count} trace${panel.count === 1 ? '' : 's'}</span><span>${escapeHtml(panel.latest_event)}</span></div>
            <pre>${escapeHtml(panel.latest_content)}</pre>
          </div>
        </details>
      </article>`;
  }).join('');
}

function renderTraceFilters() {
  const roles = ['all', 'planner', 'researcher', 'executor', 'critic', 'reflector', 'memory'];
  els.traceFilters.innerHTML = roles.map((role) => `<button class="filter-chip ${state.traceFilter === role ? 'active' : ''}" data-role="${role}">${role}</button>`).join('');
  els.traceFilters.querySelectorAll('.filter-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      state.traceFilter = chip.dataset.role;
      renderTraceFilters();
      renderTraceTimeline();
    });
  });
}

function renderTraceMap() {
  const traces = state.selectedRun?.traces || [];
  const roles = ['planner', 'researcher', 'executor', 'critic', 'reflector'];
  const roleCount = roles.reduce((acc, role) => {
    acc[role] = traces.filter((trace) => trace.role === role).length;
    return acc;
  }, {});
  els.traceMap.innerHTML = roles.map((role) => {
    const meta = ROLE_META[role];
    const active = roleCount[role] > 0;
    return `<div class="flow-node ${active ? 'active' : ''}"><span>${meta.icon} ${meta.label}</span><strong>${active ? `${roleCount[role]} event${roleCount[role] === 1 ? '' : 's'}` : 'idle'}</strong><span>${active ? 'Participated in this run' : 'No activity logged'}</span></div>`;
  }).join('');
}

function renderTraceTimeline() {
  const traces = state.selectedRun?.traces || [];
  const visible = state.traceFilter === 'all' ? traces : traces.filter((trace) => trace.role === state.traceFilter);
  renderTraceMap();
  if (!visible.length) {
    els.traceTimeline.innerHTML = '<div class="empty-state">No traces for this filter.</div>';
    return;
  }
  els.traceTimeline.innerHTML = visible.map((trace) => {
    const meta = ROLE_META[trace.role] || { icon: '•', label: trace.role };
    return `
      <article class="trace-item role-${trace.role}">
        <div class="trace-top"><span class="trace-role">${meta.icon} ${escapeHtml(trace.role)}</span><span class="trace-event">${escapeHtml(trace.event_type)}</span><span class="trace-time">${formatDate(trace.created_at)}</span></div>
        <pre>${escapeHtml(trace.content)}</pre>
      </article>`;
  }).join('');
}

function renderSelectedRun() {
  if (!state.selectedRun) {
    els.detailTitle.textContent = 'Choose a run';
    els.detailEmpty.classList.remove('hidden');
    els.detailContent.classList.add('hidden');
    els.detailActions.classList.add('hidden');
    return;
  }
  const run = state.selectedRun;
  els.detailTitle.textContent = `Run #${run.id} · ${formatDepthLabel(run.depth_mode)}`;
  els.detailEmpty.classList.add('hidden');
  els.detailContent.classList.remove('hidden');
  els.detailActions.classList.remove('hidden');
  els.openRunLink.href = `/runs/${run.id}`;
  els.runStatus.textContent = run.status;
  els.runProvider.textContent = `${(run.provider || 'demo').toUpperCase()} / ${run.model_name || '-'}`;
  els.runScore.textContent = Number(run.critic_score).toFixed(2);
  els.runLatency.textContent = formatDuration(run.duration_ms);
  els.runTraces.textContent = run.trace_count;
  if (els.runDepth) els.runDepth.textContent = formatDepthLabel(run.depth_mode);
  els.runGoal.textContent = run.goal;
  els.runPlan.textContent = run.plan_text;
  els.runAnswer.textContent = run.final_answer;
  renderAgentPanels();
  renderTraceFilters();
  renderTraceTimeline();
}

async function selectRun(runId) {
  state.selectedRunId = runId;
  renderRuns();
  state.selectedRun = await getJson(`/api/runs/${runId}`);
  renderSelectedRun();
  history.replaceState({}, '', `/runs/${runId}`);
}

function syncBenchmarkControls(evals) {
  const suites = evals?.suites || [];
  if (!els.defaultSuiteSelect) return;
  els.defaultSuiteSelect.innerHTML = suites.map((suite) => `<option value="${escapeHtml(suite.name)}">${escapeHtml(suite.title)} (${escapeHtml(suite.name)})</option>`).join('');
  const saved = getDefaultSuiteName();
  const nextValue = suites.find((suite) => suite.name === saved)?.name || suites[0]?.name || '';
  if (nextValue) {
    els.defaultSuiteSelect.value = nextValue;
    setDefaultSuiteName(nextValue);
    els.runBenchmarkButton.disabled = false;
    els.evalLastSuite.textContent = `Default suite: ${nextValue}`;
  } else {
    els.runBenchmarkButton.disabled = true;
  }
  els.autoEvalToggle.checked = getAutoEvalEnabled();
}

async function triggerBenchmarkRun(suiteName, sourceButton) {
  if (!suiteName) return;
  const previousText = sourceButton.textContent;
  sourceButton.disabled = true;
  sourceButton.textContent = 'Running...';
  try {
    await getJson('/api/evals/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ suite_name: suiteName, llm_override: getLLMOverride() }),
    });
    const evals = await getJson('/api/evals/dashboard');
    renderEvalDashboard(evals);
    renderControlCenter({ ...state.dashboard, evals, stats: state.dashboard?.stats || { total_runs: 0, avg_score: 0 } });
  } finally {
    sourceButton.disabled = false;
    sourceButton.textContent = previousText;
  }
}

function renderEvalSuites(evals) {
  if (!els.evalSuiteGrid) return;
  els.evalSuiteCount.textContent = `${evals.stats.suite_count} suites`;
  els.evalRunCount.textContent = `${evals.stats.eval_run_count} eval runs`;
  els.evalAvgScore.textContent = Number(evals.stats.avg_eval_score).toFixed(3);
  els.evalAvgPassRate.textContent = `${Number(evals.stats.avg_pass_rate).toFixed(1)}%`;

  if (!evals.suites?.length) {
    els.evalSuiteGrid.innerHTML = '<div class="empty-state">No benchmark suites available.</div>';
    return;
  }
  els.evalSuiteGrid.innerHTML = evals.suites.map((suite) => `
    <article class="suite-card glass subtle-card">
      <div class="suite-head">
        <div>
          <p class="section-kicker">${escapeHtml(suite.name)}</p>
          <h4>${escapeHtml(suite.title)}</h4>
        </div>
        <button class="primary-button run-suite-button" data-suite-name="${escapeHtml(suite.name)}">Run suite</button>
      </div>
      <p class="suite-copy">${escapeHtml(suite.description)}</p>
      <div class="suite-meta"><span>${suite.case_count} cases</span><span>${suite.cases.map((item) => item.eval_type).filter((v, i, arr) => arr.indexOf(v) === i).join(', ')}</span></div>
      <div class="suite-tags">${suite.cases.slice(0, 6).flatMap((item) => item.tags || []).slice(0, 8).map((tag) => `<span class="mini-badge">${escapeHtml(tag)}</span>`).join('')}</div>
    </article>`).join('');

  document.querySelectorAll('.run-suite-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const suiteName = button.dataset.suiteName;
      setDefaultSuiteName(suiteName);
      syncBenchmarkControls(evals);
      await triggerBenchmarkRun(suiteName, button);
    });
  });
}

function renderEvalRuns(evals) {
  if (!els.evalRunsList) return;
  if (!evals.recent_eval_runs?.length) {
    els.evalRunsList.className = 'runs-list empty-state';
    els.evalRunsList.innerHTML = 'No eval runs yet.';
    return;
  }
  els.evalRunsList.className = 'runs-list';
  els.evalRunsList.innerHTML = evals.recent_eval_runs.map((run) => `
    <article class="eval-run-card">
      <div class="run-meta"><span class="status-pill">${escapeHtml(run.status)}</span><span class="${depthBadgeClass(run.depth_mode)}">${escapeHtml(formatDepthLabel(run.depth_mode))}</span><span>${formatDate(run.created_at)}</span></div>
      <h4>${escapeHtml(run.suite_name)}</h4>
      <p class="small-copy">${escapeHtml((run.provider || 'demo').toUpperCase())} / ${escapeHtml(run.model_name || '-')}</p>
      <div class="run-meta footer"><span>Score ${Number(run.aggregate_score).toFixed(3)}</span><span>Pass ${Number(run.pass_rate).toFixed(1)}%</span><span>${run.total_cases} cases</span></div>
      <div class="eval-case-list">${run.results.map((result) => `<div class="eval-case-row ${result.passed ? 'pass' : 'fail'}"><span>${escapeHtml(result.case_name)}</span><span>${Number(result.score).toFixed(3)}</span></div>`).join('')}</div>
    </article>`).join('');
}

function renderLastBenchmarkBanner(evals) {
  if (!els.lastBenchmarkBanner) return;
  const latest = evals?.recent_eval_runs?.[0];
  if (!latest) {
    els.lastBenchmarkBanner.classList.remove('hidden');
    els.lastBenchmarkTitle.textContent = 'No benchmark run yet';
    els.lastBenchmarkStatus.textContent = 'Ready';
    els.lastBenchmarkStatus.className = 'pill success';
    els.lastBenchmarkCopy.textContent = 'Run a benchmark manually or enable auto-run after each agent run to see pass rate and score here.';
    els.lastBenchmarkSuite.textContent = '-';
    els.lastBenchmarkScore.textContent = '-';
    els.lastBenchmarkPassRate.textContent = '-';
    els.lastBenchmarkCases.textContent = '-';
    els.lastBenchmarkProvider.textContent = '-';
    els.lastBenchmarkTime.textContent = '-';
    return;
  }

  const passRate = Number(latest.pass_rate || 0);
  const score = Number(latest.aggregate_score || 0);
  const statusClass = passRate >= 85 ? 'pill success' : passRate >= 60 ? 'pill warning' : 'pill danger-soft';
  const statusLabel = passRate >= 85 ? 'Strong' : passRate >= 60 ? 'Mixed' : 'Needs work';
  const provider = (latest.provider || 'demo').toUpperCase();

  els.lastBenchmarkBanner.classList.remove('hidden');
  els.lastBenchmarkTitle.textContent = `${latest.suite_name} benchmark completed`;
  els.lastBenchmarkStatus.textContent = statusLabel;
  els.lastBenchmarkStatus.className = statusClass;
  els.lastBenchmarkCopy.textContent = `Latest suite scored ${score.toFixed(3)} with a ${passRate.toFixed(1)}% pass rate across ${latest.total_cases} cases on ${provider}.`;
  els.lastBenchmarkSuite.textContent = latest.suite_name;
  els.lastBenchmarkScore.textContent = score.toFixed(3);
  els.lastBenchmarkPassRate.textContent = `${passRate.toFixed(1)}%`;
  els.lastBenchmarkCases.textContent = String(latest.total_cases || 0);
  els.lastBenchmarkProvider.textContent = `${provider} / ${latest.model_name || '-'}`;
  els.lastBenchmarkTime.textContent = formatDate(latest.created_at);

  els.controlLastBenchmark.textContent = statusLabel;
  els.controlBenchmarkCopy.textContent = `${latest.suite_name} · ${passRate.toFixed(1)}% pass`;
}

function renderEvalFailures(evals) {
  if (!els.evalFailures) return;
  if (!evals.latest_failures?.length) {
    els.evalFailures.className = 'failure-list empty-state';
    els.evalFailures.innerHTML = 'No failures yet.';
    return;
  }
  els.evalFailures.className = 'failure-list';
  els.evalFailures.innerHTML = evals.latest_failures.map((failure) => `
    <article class="failure-card">
      <div class="failure-top"><span class="status-pill danger">Miss</span><span>${escapeHtml(failure.suite_name)}</span></div>
      <h4>${escapeHtml(failure.case_name)}</h4>
      <p>${escapeHtml(failure.judge_summary)}</p>
      <div class="run-meta footer"><span>Score ${Number(failure.score).toFixed(3)}</span>${failure.agent_run_id ? `<a href="/runs/${failure.agent_run_id}">Run #${failure.agent_run_id}</a>` : ''}</div>
    </article>`).join('');
}

function renderEvalDashboard(evals) {
  state.evals = evals;
  syncBenchmarkControls(evals);
  renderEvalSuites(evals);
  renderEvalRuns(evals);
  renderEvalFailures(evals);
  renderLastBenchmarkBanner(evals);
  renderLineChart(els.evalScoreChart, evals.charts.score_series, 'Aggregate eval score');
  renderLineChart(els.evalPassChart, evals.charts.pass_series, 'Pass rate', (v) => `${Number(v).toFixed(0)}%`);
  renderBarChart(els.evalSuiteMix, evals.charts.suite_mix, 'suite_name', 'count');
}

function populatePromptLibrary() {
  els.promptTemplateSelect.innerHTML = Object.entries(PROMPT_LIBRARY).map(([key, item]) => `<option value="${key}">${item.title}</option>`).join('');
  els.promptCountPill.textContent = `${Object.keys(PROMPT_LIBRARY).length} templates`;
}

function setPromptTemplate(key, fill = false) {
  const template = PROMPT_LIBRARY[key] || PROMPT_LIBRARY.architecture;
  els.promptTemplateSelect.value = key;
  els.composerGuidance.textContent = template.guidance;
  document.querySelectorAll('.template-tag').forEach((tag) => tag.classList.toggle('active', tag.dataset.templateKey === key));
  if (fill) els.goalInput.value = template.text;
}

function setComplexity(level) {
  state.complexity = level;
  document.querySelectorAll('.mode-pill').forEach((button) => button.classList.toggle('active', button.dataset.complexity === level));
  const templateKey = els.promptTemplateSelect.value || 'architecture';
  const base = PROMPT_LIBRARY[templateKey]?.guidance || '';
  const suffix = level === 'concise'
    ? ' Ask for a crisp executive-level answer.'
    : level === 'deep'
      ? ' Ask for explicit tradeoffs, risks, and a fuller systems view.'
      : ' Ask for a detailed but practical answer.';
  els.composerGuidance.textContent = `${base}${suffix}`;
}

function pushLiveEvent(role, message) {
  const row = document.createElement('article');
  row.className = 'live-event';
  row.innerHTML = `<span class="dot"></span><div><strong>${escapeHtml(ROLE_META[role]?.label || role)}</strong><p>${escapeHtml(message)}</p></div><small>${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' })}</small>`;
  els.liveRunLog.prepend(row);
}

function updateLiveRole(role, status) {
  document.querySelectorAll('.mini-badge').forEach((badge) => {
    if (badge.dataset.role === role) {
      badge.classList.remove('live', 'complete');
      badge.classList.add(status === 'running' ? 'live' : status === 'done' ? 'complete' : '');
    }
  });
  els.liveAgentMap.querySelectorAll('.agent-stream-card').forEach((card) => {
    if (card.dataset.role === role) {
      card.classList.remove('running', 'done', 'waiting');
      card.classList.add(status === 'running' ? 'running' : status === 'done' ? 'done' : 'waiting');
      card.querySelector('strong').textContent = status === 'running' ? 'Running' : status === 'done' ? 'Done' : 'Queued';
    }
  });
}

function hydrateDepthSelector(config = {}) {
  if (!els.depthModeSelect) return;
  const options = Array.isArray(config.runtime_depth_options) && config.runtime_depth_options.length
    ? config.runtime_depth_options
    : ['normal', 'deep', 'exhaustive'];
  els.depthModeSelect.innerHTML = options.map((opt) => `<option value="${escapeHtml(opt)}">${escapeHtml(opt.charAt(0).toUpperCase() + opt.slice(1))}</option>`).join('');
  const preferred = getRuntimeDepthMode();
  const next = options.includes(preferred) ? preferred : (config.runtime_depth_default || options[0] || 'deep');
  setRuntimeDepthMode(next);
}

function startLiveRunSimulation(goal) {
  stopLiveRunSimulation();
  els.runProgress.classList.remove('hidden');
  els.liveRunLog.innerHTML = '';
  els.liveRunTitle.textContent = 'Agent run in progress';
  const runtimeDepth = getRuntimeDepthMode();
  els.liveRunCopy.textContent = `Streaming the planner, researcher, executor, critic, and reflector as they work in ${runtimeDepth} mode.`;
  document.querySelectorAll('.mini-badge').forEach((badge) => badge.classList.remove('live', 'complete'));
  els.liveAgentMap.querySelectorAll('.agent-stream-card').forEach((card) => {
    card.classList.remove('running', 'done');
    card.classList.add('waiting');
    card.querySelector('strong').textContent = 'Queued';
  });
  pushLiveEvent('planner', `Accepted goal: ${goal.slice(0, 120)}${goal.length > 120 ? '…' : ''}`);

  const sequence = LIVE_SCENARIOS[state.complexity] || LIVE_SCENARIOS.advanced;
  state.liveTick = 0;
  state.liveInterval = window.setInterval(() => {
    const step = sequence[state.liveTick];
    if (!step) return;
    const [role, message] = step;
    updateLiveRole(role, 'running');
    pushLiveEvent(role, message);
    window.setTimeout(() => updateLiveRole(role, 'done'), 700);
    state.liveTick += 1;
    if (state.liveTick >= sequence.length) {
      window.clearInterval(state.liveInterval);
      state.liveInterval = null;
    }
  }, 950);
}

function stopLiveRunSimulation(completed = false) {
  if (state.liveInterval) {
    window.clearInterval(state.liveInterval);
    state.liveInterval = null;
  }
  if (completed) {
    els.liveRunTitle.textContent = 'Latest run completed';
    els.liveRunCopy.textContent = 'Execution finished. Review the selected run panel for the final answer, agent details, and observability trail.';
  }
}

async function loadDashboard() {
  const data = await getJson('/api/dashboard');
  state.dashboard = data;
  state.runs = data.recent_runs;
  state.memories = data.memories;
  renderControlCenter(data);
  renderMetrics(data);
  renderLineChart(els.scoreChart, data.charts.score_series, 'Critic score');
  renderLineChart(els.latencyChart, data.charts.latency_series, 'Latency', (v) => formatDuration(v));
  renderBarChart(els.runsChart, data.charts.daily_counts, 'label', 'count');
  renderBarChart(els.providerChart, data.charts.provider_mix, 'provider', 'count');
  renderBarChart(els.roleChart, data.charts.role_distribution, 'role', 'count');
  renderRuns();
  renderMemories();
  renderEvalDashboard(data.evals);
  if (state.selectedRunId) {
    await selectRun(state.selectedRunId);
  } else if (state.runs.length) {
    await selectRun(state.runs[0].id);
  }
}

async function runGoal(goal) {
  els.runButton.disabled = true;
  els.runBenchmarkButton.disabled = true;
  startLiveRunSimulation(goal);
  try {
    const autoEval = getAutoEvalEnabled();
    const evalSuiteName = getDefaultSuiteName();
    const result = await getJson('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goal, auto_eval: autoEval, eval_suite_name: evalSuiteName || null, depth_mode: getRuntimeDepthMode() }),
    });
    state.selectedRunId = result.run_id;
    stopLiveRunSimulation(true);
    pushLiveEvent('executor', 'Final answer stored and selected run updated.');
    await loadDashboard();
  } finally {
    els.runButton.disabled = false;
    els.runBenchmarkButton.disabled = !getDefaultSuiteName();
  }
}

function setupEvents() {
  populatePromptLibrary();
  setPromptTemplate('architecture');
  setComplexity('advanced');

  els.goalForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const goal = els.goalInput.value.trim();
    if (!goal) return;
    await runGoal(goal);
  });

  els.refresh.addEventListener('click', loadDashboard);

  els.autoEvalToggle?.addEventListener('change', (event) => {
    setAutoEvalEnabled(Boolean(event.target.checked));
  });

  els.defaultSuiteSelect?.addEventListener('change', (event) => {
    setDefaultSuiteName(event.target.value);
    if (state.evals) syncBenchmarkControls(state.evals);
  });

  els.depthModeSelect?.addEventListener('change', (event) => {
    setRuntimeDepthMode(event.target.value);
  });

  els.runBenchmarkButton?.addEventListener('click', async () => {
    const suiteName = getDefaultSuiteName();
    await triggerBenchmarkRun(suiteName, els.runBenchmarkButton);
  });

  els.runSearch.addEventListener('input', (event) => {
    state.runSearch = event.target.value;
    renderRuns();
  });

  document.querySelectorAll('.prompt-chip').forEach((chip) => chip.addEventListener('click', () => {
    const key = chip.dataset.templateKey || 'architecture';
    setPromptTemplate(key, true);
    els.goalInput.focus();
  }));

  els.promptTemplateSelect?.addEventListener('change', (event) => {
    setPromptTemplate(event.target.value, true);
  });

  els.templateTags?.querySelectorAll('.template-tag').forEach((tag) => tag.addEventListener('click', () => {
    setPromptTemplate(tag.dataset.templateKey, true);
    els.goalInput.focus();
  }));

  els.complexityToggle?.querySelectorAll('.mode-pill').forEach((button) => button.addEventListener('click', () => {
    setComplexity(button.dataset.complexity);
  }));

  document.querySelectorAll('.nav-pill').forEach((pill) => pill.addEventListener('click', () => {
    document.getElementById(pill.dataset.scrollTarget)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.querySelectorAll('.nav-pill').forEach((button) => button.classList.remove('active'));
    pill.classList.add('active');
  }));

  document.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((item) => item.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((item) => item.classList.remove('active'));
    tab.classList.add('active');
    document.querySelector(`.tab-panel[data-panel="${tab.dataset.tab}"]`)?.classList.add('active');
  }));

  els.copyRunJson.addEventListener('click', async () => {
    if (!state.selectedRun) return;
    await navigator.clipboard.writeText(JSON.stringify(state.selectedRun, null, 2));
    els.copyRunJson.textContent = 'Copied';
    setTimeout(() => { els.copyRunJson.textContent = 'Copy JSON'; }, 1200);
  });
}

setupEvents();
loadDashboard().catch((error) => {
  console.error(error);
  document.body.insertAdjacentHTML('beforeend', `<div class="toast">Could not load dashboard: ${escapeHtml(error.message)}</div>`);
});


/* === Final polish pass === */
function setNavActiveBySection() {
  const sections = document.querySelectorAll('[id]');
  const pills = document.querySelectorAll('.nav-pill[data-scroll-target]');
  if (!sections.length || !pills.length || !('IntersectionObserver' in window)) return;
  const pillMap = new Map(Array.from(pills).map((pill) => [pill.dataset.scrollTarget, pill]));
  const observer = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    pills.forEach((pill) => pill.classList.remove('active'));
    pillMap.get(visible.target.id)?.classList.add('active');
  }, { rootMargin: '-20% 0px -55% 0px', threshold: [0.15, 0.35, 0.6] });
  ['composer-card','metrics-grid','evals-panel','detail-panel','memory-panel'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) observer.observe(el);
  });
}

function hydratePromptMeta() {
  if (els.promptCountPill) els.promptCountPill.textContent = `${Object.keys(PROMPT_LIBRARY).length} templates`;
}

function restoreUiPrefs() {
  const savedComplexity = localStorage.getItem('aos:complexity');
  if (savedComplexity && ['concise','advanced','deep'].includes(savedComplexity)) {
    state.complexity = savedComplexity;
    document.querySelectorAll('.mode-pill').forEach((btn) => btn.classList.toggle('active', btn.dataset.complexity === savedComplexity));
  }
  const savedTemplate = localStorage.getItem('aos:template');
  if (savedTemplate && PROMPT_LIBRARY[savedTemplate] && els.promptTemplateSelect) {
    els.promptTemplateSelect.value = savedTemplate;
  }
  const savedDepthMode = localStorage.getItem('aos:depthMode');
  if (savedDepthMode && ['normal','deep','exhaustive'].includes(savedDepthMode)) {
    state.runtimeDepth = savedDepthMode;
    if (els.depthModeSelect) els.depthModeSelect.value = savedDepthMode;
  }
}

function persistUiPrefs() {
  document.querySelectorAll('.mode-pill').forEach((btn) => {
    btn.addEventListener('click', () => localStorage.setItem('aos:complexity', btn.dataset.complexity));
  });
  if (els.promptTemplateSelect) {
    els.promptTemplateSelect.addEventListener('change', () => localStorage.setItem('aos:template', els.promptTemplateSelect.value));
  }
  if (els.depthModeSelect) {
    els.depthModeSelect.addEventListener('change', () => localStorage.setItem('aos:depthMode', els.depthModeSelect.value));
  }
  document.querySelectorAll('.template-tag, .prompt-chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.templateKey;
      if (key) localStorage.setItem('aos:template', key);
    });
  });
}

setNavActiveBySection();
hydratePromptMeta();
restoreUiPrefs();
persistUiPrefs();

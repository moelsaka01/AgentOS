from __future__ import annotations

import argparse
import json

from app.db import SessionLocal
from app.evals import BenchmarkRunner, EvalSeeder, serialize_eval_run
from app.models import EvalSuite


def main() -> None:
    parser = argparse.ArgumentParser(description='Run AOS benchmark suites.')
    parser.add_argument('--suite', default='core_reasoning', help='Suite name to execute')
    parser.add_argument('--list', action='store_true', help='List available suites')
    args = parser.parse_args()

    db = SessionLocal()
    try:
        EvalSeeder(db).seed()
        if args.list:
            suites = db.query(EvalSuite).order_by(EvalSuite.name.asc()).all()
            print('\n'.join(f'{suite.name}: {suite.title}' for suite in suites))
            return
        eval_run = BenchmarkRunner(db).run_suite(args.suite)
        print(json.dumps(serialize_eval_run(eval_run), indent=2, default=str))
    finally:
        db.close()


if __name__ == '__main__':
    main()
